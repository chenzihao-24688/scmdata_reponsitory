DECLARE
  p_produ_rec                    t_production_progress%ROWTYPE;
  v_count                        NUMBER;
  v_latest_planned_delivery_date DATE;
BEGIN
  FOR po_rec IN (SELECT *
                   FROM scmdata.t_ordered po
                  WHERE po.company_id = 'b6cc680ad0f599cde0531164a8c0337f'
                    AND po.order_status = 'OS01') LOOP
  
    FOR pln_rec IN (SELECT *
                      FROM scmdata.t_orders t
                     WHERE po_rec.company_id = t.company_id
                       AND po_rec.order_code = t.order_id) LOOP
    
      SELECT *
        INTO p_produ_rec
        FROM scmdata.t_production_progress t
       WHERE t.company_id = pln_rec.company_id
         AND t.order_id = pln_rec.order_id
         AND t.goo_id = pln_rec.goo_id;
      --���¼ƻ�����
      v_latest_planned_delivery_date := scmdata.pkg_production_progress.get_order_date(p_company_id => po_rec.company_id,
                                                                                       p_order_code => po_rec.order_code,
                                                                                       p_status     => 2);
    
      UPDATE scmdata.t_production_progress t
         SET t.latest_planned_delivery_date = v_latest_planned_delivery_date
         where t.company_id = pln_rec.company_id
         AND t.order_id = pln_rec.order_id
         AND t.goo_id = pln_rec.goo_id;
    
      scmdata.pkg_production_progress.sync_orders_update_product(po_header_rec => po_rec,
                                                                 po_line_rec   => pln_rec,
                                                                 p_produ_rec   => p_produ_rec);
    END LOOP;
  END LOOP;
END;
/
DECLARE
--�ۿ�����ⵥ
v_from_sql1 clob;
v_from_sql2 clob;
BEGIN
  update bw3.sys_field_list t set t.caption = '���¼ƻ�����' where t.field_name = 'LATEST_PLANNED_DELIVERY_DATE_PR';
  
  v_from_sql1 := q'[WITH delivery_amount AS
 (SELECT * FROM scmdata.t_delivery_record dr),
deduction_ratio AS
 (SELECT dc.deduction_ratio,
         dc.section_start,
         dc.section_end,
         tc.company_id,
         tc.goo_id
    FROM scmdata.t_commodity_info tc
   INNER JOIN scmdata.t_deduction_range_config dr
      ON tc.company_id = dr.company_id
     AND tc.category = dr.industry_classification
     AND tc.product_cate = dr.production_category
     AND instr(';' || dr.product_subclass || ';',
               ';' || tc.samll_category || ';') > 0
     AND dr.pause = 0
   INNER JOIN scmdata.t_deduction_dtl_config dc
      ON dr.company_id = dc.company_id
     AND dr.deduction_config_id = dc.deduction_config_id
     AND dc.pause = 0
   INNER JOIN scmdata.t_deduction_config td
      ON td.company_id = dc.company_id
     AND td.deduction_config_id = dc.deduction_config_id
     AND td.pause = 0)
SELECT order_id "�������ݺ�",
       style_number "����",
       delay_amount "����",
       order_price "����",
       delay_amount * order_price "�ܼ�",
       to_char(delivery_date, 'yyyy-mm-dd') "Լ������",
       to_char(arrival_date, 'yyyy-mm-dd') "ʵ�ʽ���",
       detailed_reasons "�ۿ�ԭ��",
       deduction_ratio "Ӧ�۱���",
       actual_discount_price "Ӧ�۽��",
       adjust_reason "��ע"
  FROM (SELECT td.order_id order_id,
               (SELECT tc.style_number
                  FROM scmdata.t_commodity_info tc
                 WHERE tc.company_id = pr.company_id
                   AND tc.goo_id = pr.goo_id) style_number,
               decode(td.orgin,
                      'SC',
                      nvl(abn.delay_amount, 0),
                      'MA',
                      (SELECT SUM(dr1.delivery_amount)
                         FROM delivery_amount dr1
                        WHERE dr1.company_id = pr.company_id
                          AND dr1.order_code = pr.order_id
                          AND dr1.goo_id = pr.goo_id)) delay_amount,
               ln.order_price order_price,
               --td.actual_discount_price total_money,
               /*(SELECT ln.delivery_date
                FROM scmdata.t_orders ln
               WHERE ln.company_id = pr.company_id
                 AND ln.order_id = pr.order_id
                 AND ln.goo_id = pr.goo_id) delivery_date,*/
               po.delivery_date delivery_date,
               td.arrival_date arrival_date,
               decode(abn.anomaly_class,
                      'AC_QUALITY',
                      '�����ۿ�',
                      abn.detailed_reasons) detailed_reasons,
               decode(abn.deduction_method,
                      'METHOD_00',
                      abn.deduction_unit_price || 'Ԫ/��',
                      'METHOD_01',
                      NULL,
                      'METHOD_02',
                      decode(td.orgin,
                             'SC',
                             nvl((SELECT deduction_ratio
                                    FROM deduction_ratio drt
                                   WHERE drt.company_id = pr.company_id
                                     AND drt.goo_id = pr.goo_id
                                     AND (abn.delay_date >= drt.section_start AND
                                         abn.delay_date < drt.section_end)) || '%',
                                 NULL),
                             'MA',
                             abn.deduction_unit_price || '%',
                             NULL)) deduction_ratio,
               td.actual_discount_price,
               td.adjust_reason
          FROM scmdata.t_deduction td
         INNER JOIN scmdata.t_production_progress pr
            ON td.company_id = pr.company_id
           AND td.order_id = pr.order_id
         INNER JOIN scmdata.t_ordered po
            ON po.company_id = pr.company_id
           AND po.order_code = pr.order_id
         INNER JOIN scmdata.t_orders ln
            ON pr.company_id = ln.company_id
           AND pr.order_id = ln.order_id
           AND pr.goo_id = ln.goo_id
         INNER JOIN scmdata.t_abnormal abn
            ON pr.company_id = abn.company_id
           AND pr.order_id = abn.order_id
           AND pr.goo_id = abn.goo_id
           AND td.abnormal_id = abn.abnormal_id
         WHERE td.company_id = %default_company_id%
           AND td.order_id = :order_code)
UNION ALL
SELECT '�ϼƽ��' "�������ݺ�",
       NULL "����",
       NULL "����",
       NULL "����",
       NULL "�ܼ�",
       NULL "Լ������",
       NULL "ʵ�ʽ���",
       NULL "�ۿ�ԭ��",
       NULL "Ӧ�۱���",
       (SELECT SUM(td.actual_discount_price)
          FROM scmdata.t_deduction td
         WHERE td.company_id = a.company_id
           AND td.order_id = a.order_code) "Ӧ�۽��",
       NULL "��ע"
  FROM scmdata.t_ordered a
 WHERE a.company_id = %default_company_id% AND a.order_code = :order_code]';
 
 v_from_sql2 := q'[WITH delivery_amount AS
 (SELECT * FROM scmdata.t_delivery_record dr),
deduction_ratio AS
 (SELECT dc.deduction_ratio,
         dc.section_start,
         dc.section_end,
         tc.company_id,
         tc.goo_id
    FROM scmdata.t_commodity_info tc
   INNER JOIN scmdata.t_deduction_range_config dr
      ON tc.company_id = dr.company_id
     AND tc.category = dr.industry_classification
     AND tc.product_cate = dr.production_category
     AND instr(';' || dr.product_subclass || ';',
               ';' || tc.samll_category || ';') > 0
     AND dr.pause = 0
   INNER JOIN scmdata.t_deduction_dtl_config dc
      ON dr.company_id = dc.company_id
     AND dr.deduction_config_id = dc.deduction_config_id
     AND dc.pause = 0
   INNER JOIN scmdata.t_deduction_config td
      ON td.company_id = dc.company_id
     AND td.deduction_config_id = dc.deduction_config_id
     AND td.pause = 0),
total_cal AS
 (SELECT SUM(td.discount_price) total_money,
         SUM(td.adjust_price) total_reduction_price,
         SUM(td.actual_discount_price) total_actual_discount_price
    FROM scmdata.t_deduction td
   WHERE td.company_id = %default_company_id%
     AND td.order_id = :order_code
     AND sign(td.adjust_price) = -1)
SELECT order_id              "�������ݺ�",
       style_number          "����",
       delay_amount          "����",
       order_price   "����",
       delay_amount*order_price           "�ܼ�",
       to_char(delivery_date,'yyyy-mm-dd')         "Լ������",
       to_char(arrival_date,'yyyy-mm-dd')          "ʵ�ʽ���",
       detailed_reasons      "�ۿ�ԭ��",
       deduction_ratio       "Ӧ�۱���",
       discount_price        "Ӧ�۽��",
       reduction_ratio       "�������",
       adjust_price*-1          "������",
       actual_discount_price "ʵ�۽��",
       adjust_reason         "��ע"
  FROM (SELECT td.order_id order_id,
               (SELECT tc.style_number
                  FROM scmdata.t_commodity_info tc
                 WHERE tc.company_id = pr.company_id
                   AND tc.goo_id = pr.goo_id) style_number,
               decode(td.orgin,
                      'SC',
                      nvl(abn.delay_amount, 0),
                      'MA',
                      (SELECT SUM(dr1.delivery_amount)
                         FROM delivery_amount dr1
                        WHERE dr1.company_id = pr.company_id
                          AND dr1.order_code = pr.order_id
                          AND dr1.goo_id = pr.goo_id)) delay_amount,
               ln.order_price order_price,
               --td.actual_discount_price total_money,
               --ln.delivery_date delivery_date,
               po.delivery_date delivery_date,
               td.arrival_date arrival_date,
               decode(abn.anomaly_class,'AC_QUALITY','�����ۿ�',abn.detailed_reasons) detailed_reasons,
               decode(abn.deduction_method,
                      'METHOD_00',
                      abn.deduction_unit_price || 'Ԫ/��',
                      'METHOD_01',
                      NULL,
                      'METHOD_02',
                      decode(td.orgin,
                             'SC',
                             nvl((SELECT deduction_ratio
                                    FROM deduction_ratio drt
                                   WHERE drt.company_id = pr.company_id
                                     AND drt.goo_id = pr.goo_id
                                     AND (abn.delay_date >= drt.section_start AND
                                         abn.delay_date < drt.section_end)) || '%',
                                 NULL),
                             'MA',
                             abn.deduction_unit_price || '%',
                             NULL)) deduction_ratio,
               td.discount_price,
               '' reduction_ratio,
               td.adjust_price,
               td.actual_discount_price,
               td.adjust_reason
          FROM scmdata.t_deduction td
         INNER JOIN scmdata.t_production_progress pr
            ON td.company_id = pr.company_id
           AND td.order_id = pr.order_id
         INNER JOIN scmdata.t_ordered po
            ON po.company_id = pr.company_id
           AND po.order_code = pr.order_id
         INNER JOIN scmdata.t_orders ln 
            ON pr.company_id = ln.company_id
           AND pr.order_id = ln.order_id
           AND pr.goo_id = ln.goo_id
         INNER JOIN scmdata.t_abnormal abn
            ON pr.company_id = abn.company_id
           AND pr.order_id = abn.order_id
           AND pr.goo_id = abn.goo_id
           AND td.abnormal_id = abn.abnormal_id
         WHERE td.company_id = %default_company_id%
           AND td.order_id = :order_code
           AND sign(td.adjust_price) = -1)
UNION ALL
SELECT '�ϼƽ��' "�������ݺ�",
       NULL "����",
       NULL "����",
       NULL "����",
       NULL "�ܼ�",
       NULL "Լ������",
       NULL "ʵ�ʽ���",
       NULL "�ۿ�ԭ��",
       NULL "Ӧ�۱���",
       (SELECT td1.total_money FROM total_cal td1) "Ӧ�۽��",
       NULL "�������",
       (SELECT td2.total_reduction_price*-1 FROM total_cal td2) "������",
       (SELECT td3.total_actual_discount_price FROM total_cal td3) "ʵ�۽��",
       NULL "��ע"
  FROM scmdata.t_ordered a
 WHERE a.company_id = %default_company_id% AND a.order_code = :order_code]';
 
 update bw3.sys_file_template_table t  set t.form_sql = v_from_sql1 where t.element_id  = 'word_a_product_130_1';
 update bw3.sys_file_template_table t  set t.form_sql = v_from_sql2 where t.element_id  = 'word_a_product_130_2';
END;
