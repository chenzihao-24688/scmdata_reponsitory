grant select on mdmdata.T_SUPPLIER_COOP_ITF to T_SUPPLIER_COOP_ITF;
