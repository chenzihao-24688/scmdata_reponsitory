BEGIN
  UPDATE scmdata.sys_company_user_role ur
     SET ur.user_id = 'f646625d7acf43eae0531f64a8c05e13'
   WHERE ur.company_id = 'f6337fda95d23a8de0531e64a8c07164';
END;
/
