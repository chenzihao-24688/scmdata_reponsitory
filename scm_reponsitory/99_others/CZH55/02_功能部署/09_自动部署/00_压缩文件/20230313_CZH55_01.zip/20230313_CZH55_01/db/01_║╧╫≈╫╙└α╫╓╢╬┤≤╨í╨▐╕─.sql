alter table scmdata.t_ask_scope modify cooperation_subcategory VARCHAR2(4000);
alter table scmdata.t_factory_report_ability modify cooperation_subcategory VARCHAR2(4000);
