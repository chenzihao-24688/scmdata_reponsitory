BEGIN
  INSERT INTO scmdata.dic_county
    (countyid, county, cityno, pause, districtid)
  VALUES
    (330113, '��ƽ��', 330100, 0, NULL);

END;
/
