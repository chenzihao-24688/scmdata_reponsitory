CREATE TABLE scmdata.t_supplier_info_bak_2 AS SELECT * FROM scmdata.t_supplier_info WHERE 1 = 1;
/
