BEGIN
DELETE FROM bw3.sys_cond_rela a WHERE a.cond_id LIKE '%action_a_product_110_3%';
DELETE FROM bw3.sys_cond_list a WHERE a.cond_id LIKE '%action_a_product_110_3%';
END;
/
