DROP TABLE scmdata.t_abnormal_bak;
CREATE TABLE scmdata.t_abnormal_bak AS SELECT * FROM scmdata.t_abnormal WHERE 1 = 1;
/
