ALTER table scmdata.t_queue_iflrows modify IR_COLVALUE5 VARCHAR2(4000);
