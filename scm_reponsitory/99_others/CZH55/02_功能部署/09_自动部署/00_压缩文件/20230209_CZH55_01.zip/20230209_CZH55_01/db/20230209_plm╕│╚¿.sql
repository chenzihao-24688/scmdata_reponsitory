GRANT select, insert, update, delete, debug, read on SCMDATA.FILE_INFO to PLM;
/
grant select, insert, update, delete, debug, read on SCMDATA.FILE_DATA to PLM;
/
