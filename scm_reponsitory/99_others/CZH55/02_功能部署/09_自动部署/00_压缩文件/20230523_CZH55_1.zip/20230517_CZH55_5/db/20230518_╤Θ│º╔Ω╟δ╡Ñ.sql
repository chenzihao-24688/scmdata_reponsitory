BEGIN
DELETE from scmdata.t_factory_ask_oper_log t WHERE t.factory_ask_id = 'CA2109143591529756';
DELETE from scmdata.t_factory_ask t WHERE t.factory_ask_id = 'CA2109143591529756';
END;
/
