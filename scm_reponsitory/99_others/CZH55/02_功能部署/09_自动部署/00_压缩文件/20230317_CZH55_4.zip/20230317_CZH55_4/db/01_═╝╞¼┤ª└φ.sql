BEGIN
  UPDATE bw3.sys_field_list t
     SET t.store_source = 'MONGO#PRO'
   WHERE t.field_name IN ('AR_OTHER_INFORMATION_N', 'ASK_REPORT_FILES','ASK_OTHER_FILES');
END;
/
