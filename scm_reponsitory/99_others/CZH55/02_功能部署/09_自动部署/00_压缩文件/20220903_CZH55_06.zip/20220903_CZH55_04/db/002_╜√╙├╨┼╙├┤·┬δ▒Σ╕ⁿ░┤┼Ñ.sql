BEGIN
UPDATE bw3.sys_item_element_rela t SET t.pause = 1 WHERE t.element_id = 'action_a_supp_160_6' AND t.item_id = 'a_supp_160'; 
END;
/
