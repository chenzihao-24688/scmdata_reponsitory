DECLARE
  v_user_account_old VARCHAR2(256) := '15928780572';
  v_user_account_new VARCHAR2(256) := '18928825908';
BEGIN
  FOR user_rec IN (SELECT a.user_id
                     FROM scmdata.sys_user a
                    WHERE a.user_account = v_user_account_old) LOOP
    UPDATE scmdata.sys_company_user t
       SET t.phone = v_user_account_new
     WHERE t.user_id = user_rec.user_id;
  END LOOP;

  UPDATE scmdata.sys_user t
     SET t.user_account = v_user_account_new, t.phone = v_user_account_new
   WHERE t.user_account = v_user_account_old;

  UPDATE bw3.sys_oper_logs t
     SET t.user_id = v_user_account_new
   WHERE t.user_id = v_user_account_old;
END;
/
