BEGIN
UPDATE bw3.sys_cond_rela t SET t.ctl_type = '13' WHERE t.cond_id  ='cond_a_supp_160_auto_1';
END;
/
