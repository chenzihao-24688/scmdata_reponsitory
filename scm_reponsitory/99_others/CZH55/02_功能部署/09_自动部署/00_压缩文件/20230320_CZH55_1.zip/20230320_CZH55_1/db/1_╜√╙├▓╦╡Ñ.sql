BEGIN
UPDATE bw3.sys_tree_list t SET t.pause = 1 WHERE t.item_id = 'a_coop_330';
END;
/
