begin
insert into scmdata.sys_app_privilege (PRIV_ID, PRIV_NAME, PARENT_PRIV_ID, PAUSE, OBJ_TYPE, CTL_ID, ITEM_ID, CREATE_ID, CREATE_TIME, UPDATE_ID, UPDATE_TIME, COND_ID, APPLY_BELONG)
values ('P0060113', '���ɳߴ��', 'P00601', 0, 95, 'associate_a_approve_111_1', null, 'bfff0ebdd2e22b0be0550250568762e1', to_date('21-12-2022 16:26:50', 'dd-mm-yyyy hh24:mi:ss'), 'bfff0ebdd2e22b0be0550250568762e1', to_date('21-12-2022 16:26:50', 'dd-mm-yyyy hh24:mi:ss'), null, 1);

insert into scmdata.sys_app_privilege (PRIV_ID, PRIV_NAME, PARENT_PRIV_ID, PAUSE, OBJ_TYPE, CTL_ID, ITEM_ID, CREATE_ID, CREATE_TIME, UPDATE_ID, UPDATE_TIME, COND_ID, APPLY_BELONG)
values ('P0050107', '���ɳߴ��', 'P00501', 0, 95, 'associate_a_good_110', null, 'bfff0ebdd2e22b0be0550250568762e1', to_date('21-12-2022 16:23:31', 'dd-mm-yyyy hh24:mi:ss'), 'bfff0ebdd2e22b0be0550250568762e1', to_date('21-12-2022 16:23:31', 'dd-mm-yyyy hh24:mi:ss'), null, 1);

insert into scmdata.sys_app_privilege (PRIV_ID, PRIV_NAME, PARENT_PRIV_ID, PAUSE, OBJ_TYPE, CTL_ID, ITEM_ID, CREATE_ID, CREATE_TIME, UPDATE_ID, UPDATE_TIME, COND_ID, APPLY_BELONG)
values ('P0050108', '�ߴ������', 'P00501', 0, 95, 'associate_a_good_110_2', null, 'bfff0ebdd2e22b0be0550250568762e1', to_date('21-12-2022 16:24:02', 'dd-mm-yyyy hh24:mi:ss'), 'bfff0ebdd2e22b0be0550250568762e1', to_date('21-12-2022 16:24:02', 'dd-mm-yyyy hh24:mi:ss'), null, 1);

insert into scmdata.sys_app_privilege (PRIV_ID, PRIV_NAME, PARENT_PRIV_ID, PAUSE, OBJ_TYPE, CTL_ID, ITEM_ID, CREATE_ID, CREATE_TIME, UPDATE_ID, UPDATE_TIME, COND_ID, APPLY_BELONG)
values ('P0060114', '�ߴ������', 'P00601', 0, 95, 'associate_a_approve_111_4', null, 'bfff0ebdd2e22b0be0550250568762e1', to_date('21-12-2022 16:27:18', 'dd-mm-yyyy hh24:mi:ss'), 'bfff0ebdd2e22b0be0550250568762e1', to_date('21-12-2022 16:27:18', 'dd-mm-yyyy hh24:mi:ss'), null, 1);
end;
/
