DROP TRIGGER SCMDATA.trg_af_iu_supplier_group_area_config;
/
DROP TRIGGER SCMDATA.trg_af_iu_supplier_group_category_config;
/
