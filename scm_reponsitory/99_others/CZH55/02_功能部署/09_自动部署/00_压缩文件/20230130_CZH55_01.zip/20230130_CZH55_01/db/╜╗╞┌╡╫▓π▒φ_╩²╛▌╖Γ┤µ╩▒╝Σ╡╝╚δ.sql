begin
insert into scmdata.t_order_seal_time (ID, MONTH, SEAL_DAYS)
values ('1', '01', 4);

insert into scmdata.t_order_seal_time (ID, MONTH, SEAL_DAYS)
values ('2', '02', 3);

insert into scmdata.t_order_seal_time (ID, MONTH, SEAL_DAYS)
values ('3', '03', 3);

insert into scmdata.t_order_seal_time (ID, MONTH, SEAL_DAYS)
values ('4', '04', 3);

insert into scmdata.t_order_seal_time (ID, MONTH, SEAL_DAYS)
values ('5', '05', 4);

insert into scmdata.t_order_seal_time (ID, MONTH, SEAL_DAYS)
values ('6', '06', 3);

insert into scmdata.t_order_seal_time (ID, MONTH, SEAL_DAYS)
values ('7', '07', 3);

insert into scmdata.t_order_seal_time (ID, MONTH, SEAL_DAYS)
values ('8', '08', 3);

insert into scmdata.t_order_seal_time (ID, MONTH, SEAL_DAYS)
values ('9', '09', 3);

insert into scmdata.t_order_seal_time (ID, MONTH, SEAL_DAYS)
values ('10', '10', 7);

insert into scmdata.t_order_seal_time (ID, MONTH, SEAL_DAYS)
values ('11', '11', 3);

insert into scmdata.t_order_seal_time (ID, MONTH, SEAL_DAYS)
values ('12', '12', 3);

END;
/
