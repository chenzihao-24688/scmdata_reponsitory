BEGIN
DELETE from scmdata.t_factory_ask t WHERE t.factory_ask_id = 'CA2109143591529756';
END;
/
