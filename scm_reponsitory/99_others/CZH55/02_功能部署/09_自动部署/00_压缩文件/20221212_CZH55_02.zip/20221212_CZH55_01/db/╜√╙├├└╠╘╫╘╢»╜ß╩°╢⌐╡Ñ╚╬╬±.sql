UPDATE scmdata.t_day_proc t SET t.pause = 1 WHERE t.seqno = '16000';
/
