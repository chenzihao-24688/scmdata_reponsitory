BEGIN
UPDATE bw3.sys_cond_rela t SET t.pause = 1 WHERE t.cond_id = 'cond_9_auto_42' AND t.item_id = 'a_product_110';
UPDATE bw3.sys_cond_rela t SET t.pause = 1 WHERE t.cond_id = 'cond_9_auto_43' AND t.item_id = 'a_product_116';
END;
/
