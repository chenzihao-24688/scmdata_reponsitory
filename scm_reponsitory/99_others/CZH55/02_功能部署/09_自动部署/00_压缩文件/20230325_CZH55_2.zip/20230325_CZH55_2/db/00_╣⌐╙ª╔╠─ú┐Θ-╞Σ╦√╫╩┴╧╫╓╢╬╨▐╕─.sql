alter table scmdata.t_ask_record modify other_information  VARCHAR2(660);
alter table scmdata.t_factory_ask modify other_information  VARCHAR2(660);
alter table scmdata.t_factory_report modify ask_files  VARCHAR2(660);
alter table scmdata.t_supplier_info modify other_information  VARCHAR2(660);
