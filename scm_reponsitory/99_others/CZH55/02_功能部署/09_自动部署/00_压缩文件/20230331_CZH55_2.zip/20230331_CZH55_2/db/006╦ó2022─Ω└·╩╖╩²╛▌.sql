declare
begin
  scmdata.pkg_qa_report.p_t_qa_warehouse_inspect_failed(p_start_date => to_date('2023-01-01','yyyy-mm-dd'),
                                                        p_end_date   => to_date('2023-02-01','yyyy-mm-dd'));
  scmdata.pkg_qa_report.p_t_qa_ingood(p_start_date => to_date('2022-01-01','yyyy-mm-dd'),
                                      p_end_date   => to_date('2023-02-01','yyyy-mm-dd'));
end;
/
