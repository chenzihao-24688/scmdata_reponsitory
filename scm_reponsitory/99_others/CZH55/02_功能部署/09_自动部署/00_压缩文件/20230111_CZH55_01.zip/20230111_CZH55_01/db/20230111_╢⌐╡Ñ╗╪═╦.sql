--���������ѽӵ�,�����������˻�δ��ɣ�δ��ʼ
DECLARE
  CURSOR p_pro_cur IS
    SELECT *
      FROM scmdata.t_production_progress t
     WHERE t.company_id = 'b6cc680ad0f599cde0531164a8c0337f'
       AND t.product_gress_code IN
           ('GZZXS2212130104', 'GZZXS2212130105', 'GZZXS2212130106');
BEGIN
  FOR p_data_rec IN p_pro_cur LOOP
    UPDATE scmdata.t_ordered po
       SET po.order_status    = 'OS01',
           po.approve_status  = NULL --OS01 �ѽӵ�
          ,
           po.finish_time_scm = NULL
     WHERE po.company_id = p_data_rec.company_id
       AND po.order_code = p_data_rec.order_id;
  
    UPDATE scmdata.t_production_progress t
       SET t.progress_status = '00' --02 ������ 00 δ��ʼ  01 �����
     WHERE t.company_id = p_data_rec.company_id
       AND t.order_id = p_data_rec.order_id;
  END LOOP;
END;
/
