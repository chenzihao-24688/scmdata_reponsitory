DELETE FROM scmdata.t_excel_import WHERE 1 = 1;
/
BEGIN
insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00299', '30', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00260', '90', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00261', '56', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00349', '45', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00327', '100', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00264', '16', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00306', '6', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00259', '4', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00251', '6', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00151', '6', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00258', '8', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C02065', '8', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C01420', '10', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00658', '60', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00352', '48', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00354', '48', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00355', '16', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00378', '24', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00438', '45', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00345', '96', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00320', '40', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00333', '5', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00333', '5', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C02120', '5', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C02124', '10', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00326', '10', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00291', '45', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

insert into scmdata.t_excel_import (COL_1, COL_2, COL_3, COL_4, COL_5, COL_6, COL_7, COL_8, COL_9, COL_10, COL_11, COL_12, COL_13, COL_14, COL_15, COL_16, COL_17, COL_18, COL_19, COL_20)
values ('C00328', '36', '10', '80.00', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
END;
/
BEGIN
  FOR i IN (SELECT t.col_1 sup_code,
                   t.col_2 car_cnt,
                   t.col_3 hour_cnt,
                   t.col_4 product_cnt
              FROM scmdata.t_excel_import t) LOOP
    UPDATE scmdata.t_supplier_info sp
       SET sp.worker_num         = i.car_cnt,
           sp.work_hours_day     = i.hour_cnt,
           sp.product_efficiency = i.product_cnt,
           sp.update_date        = SYSDATE,
           sp.update_id          = 'ADMIN'
     WHERE sp.supplier_code = i.sup_code
       AND sp.company_id = 'b6cc680ad0f599cde0531164a8c0337f';
  END LOOP;
END;
/