BEGIN
UPDATE bw3.sys_item t SET t.show_rowid = NULL WHERE t.item_id = 'a_report_120'; 
END;
/
