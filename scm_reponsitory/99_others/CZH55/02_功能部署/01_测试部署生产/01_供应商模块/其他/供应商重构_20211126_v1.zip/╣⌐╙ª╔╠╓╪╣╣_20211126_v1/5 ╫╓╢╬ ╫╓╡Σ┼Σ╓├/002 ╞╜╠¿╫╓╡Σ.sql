INSERT INTO scmdata.sys_group_dict VALUES ('ca825057ee512fd0e0533c281cac7b50','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','��������','COM_MANUFACTURER','SUPPLIER_MANGE_DICT','','1','1','1','1','0','CZH','27-8�� -21','CZH','27-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca36b4767d620fdbe0533c281cac9d52','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','�Ƿ��Ե�','IS_TRIALORDER','SUPPLIER_MANGE_DICT','','1','1','1','1','0','admin','23-8�� -21','admin','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca46437948e0533c281cacdcde','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','����������','PRODUCT_LINE','SUPPLIER_MANGE_DICT','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca464e7948e0533c281cacdcde','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','�����ȼ�','QUALITY_STEP','SUPPLIER_MANGE_DICT','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca3994a12da127abe0533c281cac075e','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','��ͬ����','CONTRACT_TYPE','SUPPLIER_MANGE_DICT','','1','1','1','1','0','admin','23-8�� -21','admin','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca464f7948e0533c281cacdcde','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','����Ʒ��/�ͻ�_����','BRAND_TYPE','SUPPLIER_MANGE_DICT','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9e49276a5d93bf7e0533c281cac19c9','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','����Ʒ��/�ͻ�','COOPERATION_BRAND','SUPPLIER_MANGE_DICT','','1','1','1','1','0','CZH','19-8�� -21','CZH','19-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9e479227dfc3a4ee0533c281cace36b','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','��������','PRODUCT_LINK','SUPPLIER_MANGE_DICT','','1','1','1','1','0','CZH','19-8�� -21','CZH','19-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('cb9ee9208c5a5d4ce0533c281caca114','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','�鳧����','CHECK_RESULT','SUPPLIER_MANGE_DICT','','1','1','1','1','0','CZH','10-9�� -21','CZH','10-9�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c97fe881a4651acde0533c281cac8364','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','�Ե�ģʽ','TRIALORDER_TYPE','SUPPLIER_MANGE_DICT','','1','1','1','1','0','a972dd1ffe3a3a10e0533c281cac8fd7','14-8�� -21','a972dd1ffe3a3a10e0533c281cac8fd7','14-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9f488e4303f62bae0533c281cacf573','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','����״̬','COOP_STATE','SUPPLIER_MANGE_DICT','','1','1','1','1','0','admin','20-8�� -21','admin','20-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca6f0eb576825220e0533c281cac5ea5','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','��������','FA_PRODUCT_TYPE','SUPPLIER_MANGE_DICT','','1','1','1','1','0','CZH','26-8�� -21','CZH','26-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca959b909a537beee0533c281cac9866','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','�������','PATTERN_CAP','SUPPLIER_MANGE_DICT','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca959b909a547beee0533c281cac9866','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','���ϲɹ�����','FABRIC_PURCHASE_CAP','SUPPLIER_MANGE_DICT','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca959b909a557beee0533c281cac9866','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','���ϼ������','FABRIC_CHECK_CAP','SUPPLIER_MANGE_DICT','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca959b909a567beee0533c281cac9866','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','�ɱ��ȼ�','COST_STEP','SUPPLIER_MANGE_DICT','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9e4a48cd6ee3a71e0533c281caca337','c9e49276a5d93bf7e0533c281cac19c9','c9e49276a5d93bf7e0533c281cac19c9','��װ','BRA_00','COOPERATION_BRAND','','1','1','1','1','0','CZH','19-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9e4a48cd6ef3a71e0533c281caca337','c9e49276a5d93bf7e0533c281cac19c9','c9e49276a5d93bf7e0533c281cac19c9','����','BRA_01','COOPERATION_BRAND','','2','1','1','1','0','CZH','19-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9e4a48cd6f03a71e0533c281caca337','c9e49276a5d93bf7e0533c281cac19c9','c9e49276a5d93bf7e0533c281cac19c9','��ױ','BRA_02','COOPERATION_BRAND','','3','1','1','1','0','CZH','19-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9e4a48cd6f13a71e0533c281caca337','c9e49276a5d93bf7e0533c281cac19c9','c9e49276a5d93bf7e0533c281cac19c9','Ь��','BRA_03','COOPERATION_BRAND','','4','1','1','1','0','CZH','19-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca9658f5d3c505d2e0533c281cace66e','ca958bca464f7948e0533c281cacdcde','ca958bca464f7948e0533c281cacdcde','UR','00','BRAND_TYPE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca9658f5d3c605d2e0533c281cace66e','ca958bca464f7948e0533c281cacdcde','ca958bca464f7948e0533c281cacdcde','����','01','BRAND_TYPE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca9658f5d3c705d2e0533c281cace66e','ca958bca464f7948e0533c281cacdcde','ca958bca464f7948e0533c281cacdcde','�ȷ�','02','BRAND_TYPE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca9658f5d3c805d2e0533c281cace66e','ca958bca464f7948e0533c281cacdcde','ca958bca464f7948e0533c281cacdcde','����','03','BRAND_TYPE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca3994a12d9b27abe0533c281cac075e','c9e4a48cd6ee3a71e0533c281caca337','c9e4a48cd6ee3a71e0533c281caca337','ɭ��','BRA_0001','BRA_00','','1','1','1','1','0','CZH','23-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca3994a12d9c27abe0533c281cac075e','c9e4a48cd6ee3a71e0533c281caca337','c9e4a48cd6ee3a71e0533c281caca337','���','BRA_0002','BRA_00','','2','1','1','1','0','CZH','23-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca3994a12d9d27abe0533c281cac075e','c9e4a48cd6ef3a71e0533c281caca337','c9e4a48cd6ef3a71e0533c281caca337','��������','BRA_0100','BRA_01','','1','1','1','1','0','CZH','23-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca3994a12d9e27abe0533c281cac075e','c9e4a48cd6ef3a71e0533c281caca337','c9e4a48cd6ef3a71e0533c281caca337','����˿','BRA_0101','BRA_01','','1','1','1','1','0','CZH','23-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca3994a12d9f27abe0533c281cac075e','c9e4a48cd6f03a71e0533c281caca337','c9e4a48cd6f03a71e0533c281caca337','�۲ݼ�','BRA_0201','BRA_02','','1','1','1','1','0','CZH','23-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca3994a12da027abe0533c281cac075e','c9e4a48cd6f03a71e0533c281caca337','c9e4a48cd6f03a71e0533c281caca337','�շ���','BRA_0202','BRA_02','','1','1','1','1','0','CZH','23-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca3994a12da227abe0533c281cac075e','c9e4a48cd6f13a71e0533c281caca337','c9e4a48cd6f13a71e0533c281caca337','ʥ����','BRA_0301','BRA_03','','1','1','1','1','0','CZH','23-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca3994a12da327abe0533c281cac075e','c9e4a48cd6f13a71e0533c281caca337','c9e4a48cd6f13a71e0533c281caca337','����','BRA_0302','BRA_03','','1','1','1','1','0','CZH','23-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca3994a12da427abe0533c281cac075e','c9e4a48cd6f13a71e0533c281caca337','c9e4a48cd6f13a71e0533c281caca337','���','BRA_0303','BRA_03','','1','1','1','1','0','CZH','23-8�� -21','CZH','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('cb9ef4dbab475e3be0533c281cac5b22','cb9ee9208c5a5d4ce0533c281caca114','cb9ee9208c5a5d4ce0533c281caca114','�鳧ͨ��','00','CHECK_RESULT','','2','1','1','1','0','CZH','10-9�� -21','CZH','10-9�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('cb9ef4dbab485e3be0533c281cac5b22','cb9ee9208c5a5d4ce0533c281caca114','cb9ee9208c5a5d4ce0533c281caca114','�鳧��ͨ��','01','CHECK_RESULT','','3','1','1','1','0','CZH','10-9�� -21','CZH','10-9�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('cb9ef4dbab465e3be0533c281cac5b22','cb9ee9208c5a5d4ce0533c281caca114','cb9ee9208c5a5d4ce0533c281caca114','�Ե�','02','CHECK_RESULT','','1','1','1','1','0','CZH','10-9�� -21','CZH','10-9�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c699e3f0fb621427e0533c281cac74d9','ab12ca834e6d787fe053b8281cacea84','ab12ca834e6d787fe053b8281cacea84','����Ȩ�޹���','C_10','COMPANY_SECURITY_TYPE','','1','1','1','1','0','CZH','08-7�� -21','CZH','08-7�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca825218a8563119e0533c281cacaec2','ca825057ee512fd0e0533c281cac7b50','ca825057ee512fd0e0533c281cac7b50','����','00','COM_MANUFACTURER','','1','1','1','1','0','CZH','27-8�� -21','CZH','27-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca825218a8573119e0533c281cacaec2','ca825057ee512fd0e0533c281cac7b50','ca825057ee512fd0e0533c281cac7b50','��Э��','01','COM_MANUFACTURER','','1','1','1','1','0','CZH','27-8�� -21','CZH','27-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca3994a12da527abe0533c281cac075e','ca3994a12da127abe0533c281cac075e','ca3994a12da127abe0533c281cac075e','ƽ̶����','0','CONTRACT_TYPE','','1','1','1','1','0','admin','23-8�� -21','admin','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca3994a12da627abe0533c281cac075e','ca3994a12da127abe0533c281cac075e','ca3994a12da127abe0533c281cac075e','��������','1','CONTRACT_TYPE','','1','1','1','1','0','admin','23-8�� -21','admin','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9f488e4304062bae0533c281cacf573','c9f488e4303f62bae0533c281cacf573','c9f488e4303f62bae0533c281cacf573','�Ե�','COOP_01','COOP_STATE','','1','1','1','1','0','admin','20-8�� -21','admin','20-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9f488e4304162bae0533c281cacf573','c9f488e4303f62bae0533c281cacf573','c9f488e4303f62bae0533c281cacf573','����','COOP_02','COOP_STATE','','2','1','1','1','0','admin','20-8�� -21','admin','20-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9f488e4304262bae0533c281cacf573','c9f488e4303f62bae0533c281cacf573','c9f488e4303f62bae0533c281cacf573','ͣ��','COOP_03','COOP_STATE','','3','1','1','1','0','admin','20-8�� -21','admin','20-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ccb94c0a41756768e0533c281cac12cc','aec46e7249440fc2e0533c281cac94c6','aec46e7249440fc2e0533c281cac94c6','�Ե�','2','COOP_STATUS','','3','1','1','1','0','CZH','24-9�� -21','CZH','24-9�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca959b909a5d7beee0533c281cac9866','ca959b909a567beee0533c281cac9866','ca959b909a567beee0533c281cac9866','A��','00','COST_STEP','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca959b909a5e7beee0533c281cac9866','ca959b909a567beee0533c281cac9866','ca959b909a567beee0533c281cac9866','B��','01','COST_STEP','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca959b909a5f7beee0533c281cac9866','ca959b909a567beee0533c281cac9866','ca959b909a567beee0533c281cac9866','C��','02','COST_STEP','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c7342de05b580edee0533c281cac1077','c699e3f0fb621427e0533c281cac74d9','c699e3f0fb621427e0533c281cac74d9','��������','CONFIG_TYPE','C_10','','1','1','1','1','0','CZH','16-7�� -21','CZH','16-7�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c7342de05b570edee0533c281cac1077','c699e3f0fb621427e0533c281cac74d9','c699e3f0fb621427e0533c281cac74d9','�㼶����','LEVEL_TYPE','C_10','','1','1','1','1','0','CZH','16-7�� -21','CZH','16-7�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('cba188f232ac77aae0533c281cac0986','ae2410133a091c8ae055025056876ded','ae2410133a091c8ae055025056876ded','ͨ��','PASS','DICT_FLOW_STATUS','','8','1','1','1','0','CZH','10-9�� -21','CZH','22-10��-21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ceec350783ff7c24e0533c281cac078d','ae2410133a091c8ae055025056876ded','ae2410133a091c8ae055025056876ded','���ɵ���','SP_FILED','DICT_FLOW_STATUS','','10','1','1','1','0','CZH','22-10��-21','CZH','22-10��-21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('cba188f232ad77aae0533c281cac0986','ae2410133a091c8ae055025056876ded','ae2410133a091c8ae055025056876ded','��ͨ��','UNPASS','DICT_FLOW_STATUS','','9','1','1','1','0','CZH','10-9�� -21','CZH','22-10��-21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('cb9ed74249325c89e0533c281cac4599','ae63f184be143ee2e0533c281cacd6c9','ae63f184be143ee2e0533c281cacd6c9','�鳧���+������','FA13','FACTORY_ASK_FLOW','','8','1','1','1','0','CZH','10-9�� -21','CZH','25-10��-21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('cb9ed74249335c89e0533c281cac4599','ae63f184be143ee2e0533c281cacd6c9','ae63f184be143ee2e0533c281cacd6c9','�鳧����+��ͨ��','FA14','FACTORY_ASK_FLOW','','9','1','1','1','0','CZH','10-9�� -21','CZH','10-9�� -21','','0','1','0');

INSERT INTO scmdata.sys_group_dict VALUES ('cee7954124ef384ce0533c281cacfac1','ae63f184be143ee2e0533c281cacd6c9','ae63f184be143ee2e0533c281cacd6c9','��Ӧ�̵���+�ѽ���','SP_01','FACTORY_ASK_FLOW','','1','1','1','1','0','CZH','22-10��-21','CZH','22-10��-21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca6f2499a3686352e0533c281cac57a0','ca6f0eb576825220e0533c281cac5ea5','ca6f0eb576825220e0533c281cac5ea5','�ȶ���','00','FA_PRODUCT_TYPE','','1','1','1','1','0','CZH','26-8�� -21','CZH','26-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca6f2499a3696352e0533c281cac57a0','ca6f0eb576825220e0533c281cac5ea5','ca6f0eb576825220e0533c281cac5ea5','Ӧ����','01','FA_PRODUCT_TYPE','','1','1','1','1','0','CZH','26-8�� -21','CZH','26-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca37166a7e501c54e0533c281cac6483','ca36b4767d620fdbe0533c281cac9d52','ca36b4767d620fdbe0533c281cac9d52','��','0','IS_TRIALORDER','','1','1','1','1','0','admin','23-8�� -21','admin','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca37166a7e511c54e0533c281cac6483','ca36b4767d620fdbe0533c281cac9d52','ca36b4767d620fdbe0533c281cac9d52','��','1','IS_TRIALORDER','','1','1','1','1','0','admin','23-8�� -21','admin','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9165b0d8d894665e0533c281cac5a3e','c7342de05b570edee0533c281cac1077','c7342de05b570edee0533c281cac1077','�������㼶','PRODUCT_CLASS_TYPE','LEVEL_TYPE','','1','1','1','1','0','CZH','09-8�� -21','CZH','09-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca959b909a577beee0533c281cac9866','ca959b909a537beee0533c281cac9866','ca959b909a537beee0533c281cac9866','��','00','PATTERN_CAP','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca959b909a587beee0533c281cac9866','ca959b909a537beee0533c281cac9866','ca959b909a537beee0533c281cac9866','��','01','PATTERN_CAP','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca46447948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','������','00','PRODUCT_LINE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca46457948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','С����','01','PRODUCT_LINE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca46467948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','������','02','PRODUCT_LINE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca46477948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','������','03','PRODUCT_LINE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca46487948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','����JIT��ˮ','04','PRODUCT_LINE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca46497948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','��ճ��','05','PRODUCT_LINE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca464a7948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','ע����','06','PRODUCT_LINE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca464b7948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','�����','07','PRODUCT_LINE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca464c7948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','������','08','PRODUCT_LINE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca958bca464d7948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','ca958bca46437948e0533c281cacdcde','������','09','PRODUCT_LINE','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9e479227dfd3a4ee0533c281cace36b','c9e479227dfc3a4ee0533c281cace36b','c9e479227dfc3a4ee0533c281cace36b','����','001','PRODUCT_LINK','','1','1','1','1','0','CZH','19-8�� -21','CZH','19-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9e479227dfe3a4ee0533c281cace36b','c9e479227dfc3a4ee0533c281cace36b','c9e479227dfc3a4ee0533c281cace36b','������','002','PRODUCT_LINK','','2','1','1','1','0','CZH','19-8�� -21','CZH','19-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9e479227dff3a4ee0533c281cace36b','c9e479227dfc3a4ee0533c281cace36b','c9e479227dfc3a4ee0533c281cace36b','��β��','003','PRODUCT_LINK','','3','1','1','1','0','CZH','19-8�� -21','CZH','19-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9e479227e003a4ee0533c281cace36b','c9e479227dfc3a4ee0533c281cace36b','c9e479227dfc3a4ee0533c281cace36b','��֯','004','PRODUCT_LINK','','4','1','1','1','0','CZH','19-8�� -21','CZH','19-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('c9e479227e013a4ee0533c281cace36b','c9e479227dfc3a4ee0533c281cace36b','c9e479227dfc3a4ee0533c281cace36b','����','005','PRODUCT_LINK','','5','1','1','1','0','CZH','19-8�� -21','CZH','19-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('bed00ef5004b3933e0533c281cac68f0','b677c74a3dda16c0e0533c281cac27e8','b677c74a3dda16c0e0533c281cac27e8','��ȡ��','03','PROGRESS_TYPE','','1','1','1','1','0','admin','31-3�� -21','admin','31-3�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca959b909a507beee0533c281cac9866','ca958bca464e7948e0533c281cacdcde','ca958bca464e7948e0533c281cacdcde','A��','00','QUALITY_STEP','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca959b909a517beee0533c281cac9866','ca958bca464e7948e0533c281cacdcde','ca958bca464e7948e0533c281cacdcde','B��','01','QUALITY_STEP','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca959b909a527beee0533c281cac9866','ca958bca464e7948e0533c281cacdcde','ca958bca464e7948e0533c281cacdcde','C��','02','QUALITY_STEP','','1','1','1','1','0','admin','28-8�� -21','admin','28-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('cd1adde55b7773afe0533c281cac9708','b2c7b0092405122de0533c281cac6536','b2c7b0092405122de0533c281cac6536','��Ӧ�̵ȼ�','SUPPLIER_RANK_DICT','SUPPLIER_MANGE_DICT','','1','1','1','1','0','admin','29-9�� -21','admin','29-9�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca36b4767d5d0fdbe0533c281cac9d52','c97fe881a4651acde0533c281cac8364','c97fe881a4651acde0533c281cac8364','��һ��','1','TRIALORDER_TYPE','','1','1','1','1','0','admin','23-8�� -21','admin','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca36b4767d5e0fdbe0533c281cac9d52','c97fe881a4651acde0533c281cac8364','c97fe881a4651acde0533c281cac8364','������','2','TRIALORDER_TYPE','','1','1','1','1','0','admin','23-8�� -21','admin','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca36b4767d5f0fdbe0533c281cac9d52','c97fe881a4651acde0533c281cac8364','c97fe881a4651acde0533c281cac8364','�Ե�һ����','3','TRIALORDER_TYPE','','1','1','1','1','0','admin','23-8�� -21','admin','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca36b4767d600fdbe0533c281cac9d52','c97fe881a4651acde0533c281cac8364','c97fe881a4651acde0533c281cac8364','�Ե�������','4','TRIALORDER_TYPE','','1','1','1','1','0','admin','23-8�� -21','admin','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('ca36b4767d610fdbe0533c281cac9d52','c97fe881a4651acde0533c281cac8364','c97fe881a4651acde0533c281cac8364','�Ե�������','5','TRIALORDER_TYPE','','1','1','1','1','0','admin','23-8�� -21','admin','23-8�� -21','','0','0','0');

INSERT INTO scmdata.sys_group_dict VALUES ('cf7537626dbf1aade0533c281caceca7','cc8bb95973c07ee7e0533c281caccb7f','cc8bb95973c07ee7e0533c281caccb7f','��Ӧ��������Ϣ����','SUP_MSG','WECOM_ROBOT_TYPE','','1','1','1','1','0','CZH','29-10��-21','CZH','29-10��-21','','0','0','0');

