begin scmdata.pkg_day_proc.p_merge_order_dayproc; end;
