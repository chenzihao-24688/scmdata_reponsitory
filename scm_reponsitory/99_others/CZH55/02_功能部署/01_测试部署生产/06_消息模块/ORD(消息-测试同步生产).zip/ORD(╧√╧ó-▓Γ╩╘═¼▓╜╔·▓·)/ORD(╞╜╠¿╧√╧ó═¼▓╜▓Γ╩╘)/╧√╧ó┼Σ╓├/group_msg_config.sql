???prompt Importing table scmdata.sys_group_msg_config...
set feedback off
set define off
insert into scmdata.sys_group_msg_config (GROUP_MSG_ID, GROUP_MSG_NAME, APPLY_ID, PAUSE, CREATE_TIME, CREATE_ID, UPDATE_TIME, UPDATE_ID, CONFIG_ID, MEMO, CONFIG_TYPE)
values ('bfc37de4157f36e1e0533c281cac3b4f', '验厂申请', 'apply_1', 0, to_date('12-04-2021 16:42:20', 'dd-mm-yyyy hh24:mi:ss'), 'CZH', to_date('12-04-2021 16:42:20', 'dd-mm-yyyy hh24:mi:ss'), 'CZH', 'hint_2104126014018883', null, 'HINT');

insert into scmdata.sys_group_msg_config (GROUP_MSG_ID, GROUP_MSG_NAME, APPLY_ID, PAUSE, CREATE_TIME, CREATE_ID, UPDATE_TIME, UPDATE_ID, CONFIG_ID, MEMO, CONFIG_TYPE)
values ('bfc37de4158036e1e0533c281cac3b4f', '供应商管理', 'apply_3', 0, to_date('12-04-2021 16:59:44', 'dd-mm-yyyy hh24:mi:ss'), 'CZH', to_date('12-04-2021 16:59:44', 'dd-mm-yyyy hh24:mi:ss'), 'CZH', 'hint_2104126118444984', null, 'HINT');

insert into scmdata.sys_group_msg_config (GROUP_MSG_ID, GROUP_MSG_NAME, APPLY_ID, PAUSE, CREATE_TIME, CREATE_ID, UPDATE_TIME, UPDATE_ID, CONFIG_ID, MEMO, CONFIG_TYPE)
values ('bfbf206e13fd0acae0533c281cace147', '验厂管理', 'apply_2', 0, to_date('12-04-2021 17:05:38', 'dd-mm-yyyy hh24:mi:ss'), 'CZH', to_date('12-04-2021 17:05:38', 'dd-mm-yyyy hh24:mi:ss'), 'CZH', 'hint_2104126153891885', null, 'HINT');

insert into scmdata.sys_group_msg_config (GROUP_MSG_ID, GROUP_MSG_NAME, APPLY_ID, PAUSE, CREATE_TIME, CREATE_ID, UPDATE_TIME, UPDATE_ID, CONFIG_ID, MEMO, CONFIG_TYPE)
values ('bfbf206e13fc0acae0533c281cace147', '准入审批', 'apply_1', 0, to_date('12-04-2021 15:54:25', 'dd-mm-yyyy hh24:mi:ss'), 'CZH', to_date('12-04-2021 15:54:25', 'dd-mm-yyyy hh24:mi:ss'), 'CZH', 'hint_2104125726584782', null, 'HINT');

prompt Done.
