???prompt Importing table scmdata.sys_company_msg_config...
set feedback off
set define off
insert into scmdata.sys_company_msg_config (COMPANY_MSG_ID, GROUP_MSG_ID, COMPANY_ID, USER_ID, PAUSE, CREATE_TIME, CREATE_ID, UPDATE_TIME, UPDATE_ID, MEMO, TOMORROW_FLAG)
values ('bfc37de4158336e1e0533c281cac3b4f', 'bfbf206e13fc0acae0533c281cace147', 'a972dd1ffe3b3a10e0533c281cac8fd7', 'ZXP', 0, to_date('12-04-2021 17:10:47', 'dd-mm-yyyy hh24:mi:ss'), 'ZXP', to_date('12-04-2021 17:10:47', 'dd-mm-yyyy hh24:mi:ss'), 'ZXP', null, 0);

insert into scmdata.sys_company_msg_config (COMPANY_MSG_ID, GROUP_MSG_ID, COMPANY_ID, USER_ID, PAUSE, CREATE_TIME, CREATE_ID, UPDATE_TIME, UPDATE_ID, MEMO, TOMORROW_FLAG)
values ('bfc3e46d68683c50e0533c281cac0d54', 'bfbf206e13fd0acae0533c281cace147', 'a972dd1ffe3b3a10e0533c281cac8fd7', 'adbf482191bf658ee055025056876ded', 0, to_date('12-04-2021 17:11:00', 'dd-mm-yyyy hh24:mi:ss'), 'adbf482191bf658ee055025056876ded', to_date('12-04-2021 17:11:00', 'dd-mm-yyyy hh24:mi:ss'), 'adbf482191bf658ee055025056876ded', null, 0);

insert into scmdata.sys_company_msg_config (COMPANY_MSG_ID, GROUP_MSG_ID, COMPANY_ID, USER_ID, PAUSE, CREATE_TIME, CREATE_ID, UPDATE_TIME, UPDATE_ID, MEMO, TOMORROW_FLAG)
values ('bfc37de4158436e1e0533c281cac3b4f', 'bfc37de4157f36e1e0533c281cac3b4f', 'a972dd1ffe3b3a10e0533c281cac8fd7', 'add385ad8b286fe6e055025056876ded', 0, to_date('12-04-2021 17:11:37', 'dd-mm-yyyy hh24:mi:ss'), 'add385ad8b286fe6e055025056876ded', to_date('12-04-2021 17:11:37', 'dd-mm-yyyy hh24:mi:ss'), 'add385ad8b286fe6e055025056876ded', null, 0);

insert into scmdata.sys_company_msg_config (COMPANY_MSG_ID, GROUP_MSG_ID, COMPANY_ID, USER_ID, PAUSE, CREATE_TIME, CREATE_ID, UPDATE_TIME, UPDATE_ID, MEMO, TOMORROW_FLAG)
values ('bfc37de4158536e1e0533c281cac3b4f', 'bfc37de4158036e1e0533c281cac3b4f', 'a972dd1ffe3b3a10e0533c281cac8fd7', 'add385ad8b286fe6e055025056876ded', 0, to_date('12-04-2021 17:11:49', 'dd-mm-yyyy hh24:mi:ss'), 'add385ad8b286fe6e055025056876ded', to_date('12-04-2021 17:11:49', 'dd-mm-yyyy hh24:mi:ss'), 'add385ad8b286fe6e055025056876ded', null, 0);

insert into scmdata.sys_company_msg_config (COMPANY_MSG_ID, GROUP_MSG_ID, COMPANY_ID, USER_ID, PAUSE, CREATE_TIME, CREATE_ID, UPDATE_TIME, UPDATE_ID, MEMO, TOMORROW_FLAG)
values ('bfc37de4158636e1e0533c281cac3b4f', 'bfbf206e13fd0acae0533c281cace147', 'a972dd1ffe3b3a10e0533c281cac8fd7', 'add385ad8b286fe6e055025056876ded', 0, to_date('12-04-2021 17:12:02', 'dd-mm-yyyy hh24:mi:ss'), 'add385ad8b286fe6e055025056876ded', to_date('12-04-2021 17:12:02', 'dd-mm-yyyy hh24:mi:ss'), 'add385ad8b286fe6e055025056876ded', null, 0);

insert into scmdata.sys_company_msg_config (COMPANY_MSG_ID, GROUP_MSG_ID, COMPANY_ID, USER_ID, PAUSE, CREATE_TIME, CREATE_ID, UPDATE_TIME, UPDATE_ID, MEMO, TOMORROW_FLAG)
values ('bfc37de4158736e1e0533c281cac3b4f', 'bfbf206e13fc0acae0533c281cace147', 'a972dd1ffe3b3a10e0533c281cac8fd7', 'add385ad8b286fe6e055025056876ded', 0, to_date('12-04-2021 17:12:12', 'dd-mm-yyyy hh24:mi:ss'), 'add385ad8b286fe6e055025056876ded', to_date('12-04-2021 17:12:12', 'dd-mm-yyyy hh24:mi:ss'), 'add385ad8b286fe6e055025056876ded', null, 0);

insert into scmdata.sys_company_msg_config (COMPANY_MSG_ID, GROUP_MSG_ID, COMPANY_ID, USER_ID, PAUSE, CREATE_TIME, CREATE_ID, UPDATE_TIME, UPDATE_ID, MEMO, TOMORROW_FLAG)
values ('bfc37de4158136e1e0533c281cac3b4f', 'bfc37de4157f36e1e0533c281cac3b4f', 'a972dd1ffe3b3a10e0533c281cac8fd7', 'adbf482191c5658ee055025056876ded', 0, to_date('12-04-2021 17:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'adbf482191c5658ee055025056876ded', to_date('12-04-2021 17:10:10', 'dd-mm-yyyy hh24:mi:ss'), 'adbf482191c5658ee055025056876ded', null, 0);

insert into scmdata.sys_company_msg_config (COMPANY_MSG_ID, GROUP_MSG_ID, COMPANY_ID, USER_ID, PAUSE, CREATE_TIME, CREATE_ID, UPDATE_TIME, UPDATE_ID, MEMO, TOMORROW_FLAG)
values ('bfc37de4158236e1e0533c281cac3b4f', 'bfc37de4158036e1e0533c281cac3b4f', 'a972dd1ffe3b3a10e0533c281cac8fd7', 'add385ad8b286fe6e055025056876ded', 0, to_date('12-04-2021 17:10:27', 'dd-mm-yyyy hh24:mi:ss'), 'add385ad8b286fe6e055025056876ded', to_date('12-04-2021 17:10:27', 'dd-mm-yyyy hh24:mi:ss'), 'add385ad8b286fe6e055025056876ded', null, 0);

prompt Done.
