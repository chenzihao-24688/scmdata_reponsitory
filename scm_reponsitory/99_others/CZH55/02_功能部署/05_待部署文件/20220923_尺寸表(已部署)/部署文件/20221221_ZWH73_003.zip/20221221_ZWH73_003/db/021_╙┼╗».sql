UPDATE bw3.sys_item_element_rela t SET t.pause = 1 WHERE t.item_id = 'a_approve_310_3' AND t.element_id = 'action_a_approve_310_3_1'; 
/
