ALTER TABLE bw3.sys_item modify sub_scripts VARCHAR2(1024);
/
