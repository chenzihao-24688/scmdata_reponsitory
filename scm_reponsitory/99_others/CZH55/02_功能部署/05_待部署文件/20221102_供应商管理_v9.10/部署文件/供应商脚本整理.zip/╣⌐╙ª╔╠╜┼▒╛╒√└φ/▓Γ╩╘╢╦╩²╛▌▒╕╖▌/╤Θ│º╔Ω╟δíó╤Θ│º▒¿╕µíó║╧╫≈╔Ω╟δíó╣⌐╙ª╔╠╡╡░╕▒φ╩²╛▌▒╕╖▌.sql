select * from scmdata.t_ask_record;
select * from scmdata.t_factory_ask;
select * from scmdata.t_factory_report;
select * from scmdata.t_supplier_info;

select * from scmdata.t_factory_ask_oper_log;

create table scmdata.t_ask_record_back230211 as select * from scmdata.t_ask_record;
create table scmdata.t_factory_ask_back230211 as select * from scmdata.t_factory_ask;
create table scmdata.t_factory_report_back230211 as select * from scmdata.t_factory_report;
create table scmdata.t_supplier_info_back230211 as select * from scmdata.t_supplier_info;

create table scmdata.t_factory_ask_oper_log_back230211 as select * from scmdata.t_factory_ask_oper_log;
