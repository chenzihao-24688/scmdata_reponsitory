alter table scmdata.t_factory_report modify factory_area number(18,2);
