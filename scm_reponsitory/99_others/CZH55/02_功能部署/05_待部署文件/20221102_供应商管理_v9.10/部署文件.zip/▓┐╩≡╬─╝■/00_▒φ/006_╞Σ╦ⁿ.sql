alter table scmdata.t_factory_report modify factory_area number(18,2);
ALTER TABLE scmdata.T_FACTORY_ASK MODIFY ASK_ADDRESS NULL;
