﻿BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t1.group_dict_value SHARING_TYPE,
       t1.group_dict_name  SHARING_TYPE_SP
  FROM scmdata.sys_group_dict t, scmdata.sys_group_dict t1
 WHERE t.group_dict_id = t1.parent_id
   AND t.group_dict_value = 'SHARE_METHOD'
   AND t1.pause = 0
ORDER BY t1.group_dict_value^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''lookup_a_supp_111_9''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SHARING_TYPE]'',q''[1]'',q''[]'',q''[SHARING_TYPE_SP]'',q''[]'',q''[]'',q''[SHARING_TYPE]'',,q''[]'',q''[SHARING_TYPE_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''lookup_a_supp_111_9''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SHARING_TYPE]'',q''[1]'',q''[]'',''lookup_a_supp_111_9'',q''[SHARING_TYPE_SP]'',q''[]'',q''[]'',q''[SHARING_TYPE]'',,q''[]'',q''[SHARING_TYPE_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'PRODUCT_LINK',
                                                               p_field_value     => 'SP_PRODUCT_LINK_N',
                                                               p_field_desc      => 'SP_PRODUCT_LINK_DESC_N');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_9''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_PRODUCT_LINK_N]'',q''[1]'',q''[]'',q''[SP_PRODUCT_LINK_DESC_N]'',q''[]'',q''[]'',q''[SP_PRODUCT_LINK_N]'',,q''[]'',q''[SP_PRODUCT_LINK_DESC_N]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_9''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_PRODUCT_LINK_N]'',q''[1]'',q''[]'',''look_a_supp_111_9'',q''[SP_PRODUCT_LINK_DESC_N]'',q''[]'',q''[]'',q''[SP_PRODUCT_LINK_N]'',,q''[]'',q''[SP_PRODUCT_LINK_DESC_N]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'QUALITY_STEP',
                                                               p_field_value     => 'SP_QUALITY_STEP_Y',
                                                               p_field_desc      => 'SP_QUALITY_STEP_DESC_Y');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_12''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_QUALITY_STEP_Y]'',q''[1]'',q''[]'',q''[SP_QUALITY_STEP_DESC_Y]'',q''[]'',q''[]'',q''[SP_QUALITY_STEP_Y]'',,q''[]'',q''[SP_QUALITY_STEP_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_12''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_QUALITY_STEP_Y]'',q''[1]'',q''[]'',''look_a_supp_111_12'',q''[SP_QUALITY_STEP_DESC_Y]'',q''[]'',q''[]'',q''[SP_QUALITY_STEP_Y]'',,q''[]'',q''[SP_QUALITY_STEP_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'PATTERN_CAP',
                                                               p_field_value     => 'SP_PATTERN_CAP_Y',
                                                               p_field_desc      => 'SP_PATTERN_CAP_DESC_Y');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_13''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_PATTERN_CAP_Y]'',q''[1]'',q''[]'',q''[SP_PATTERN_CAP_DESC_Y]'',q''[]'',q''[]'',q''[SP_PATTERN_CAP_Y]'',,q''[]'',q''[SP_PATTERN_CAP_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_13''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_PATTERN_CAP_Y]'',q''[1]'',q''[]'',''look_a_supp_111_13'',q''[SP_PATTERN_CAP_DESC_Y]'',q''[]'',q''[]'',q''[SP_PATTERN_CAP_Y]'',,q''[]'',q''[SP_PATTERN_CAP_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'SUPPLY_TYPE',
                                                               p_field_value     => 'SP_COOPERATION_MODEL_Y',
                                                               p_field_desc      => 'SP_COOPERATION_MODEL_DESC_Y');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_5''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_COOPERATION_MODEL_Y]'',q''[1]'',q''[0]'',q''[SP_COOPERATION_MODEL_DESC_Y]'',q''[]'',q''[]'',q''[SP_COOPERATION_MODEL_Y]'',1,q''[]'',q''[SP_COOPERATION_MODEL_DESC_Y]'',,q''[;]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_5''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_COOPERATION_MODEL_Y]'',q''[1]'',q''[0]'',''look_a_supp_111_5'',q''[SP_COOPERATION_MODEL_DESC_Y]'',q''[]'',q''[]'',q''[SP_COOPERATION_MODEL_Y]'',1,q''[]'',q''[SP_COOPERATION_MODEL_DESC_Y]'',,q''[;]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^--czh 重构代码
{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'PRODUCT_LINE',
                                                               p_field_value     => 'SP_PRODUCT_LINE_N',
                                                               p_field_desc      => 'SP_PRODUCT_LINE_DESC_N');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_11''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_PRODUCT_LINE_N]'',q''[1]'',q''[]'',q''[SP_PRODUCT_LINE_DESC_N]'',q''[]'',q''[]'',q''[SP_PRODUCT_LINE_N]'',1,q''[]'',q''[SP_PRODUCT_LINE_DESC_N]'',,q''[;]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_11''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_PRODUCT_LINE_N]'',q''[1]'',q''[]'',''look_a_supp_111_11'',q''[SP_PRODUCT_LINE_DESC_N]'',q''[]'',q''[]'',q''[SP_PRODUCT_LINE_N]'',1,q''[]'',q''[SP_PRODUCT_LINE_DESC_N]'',,q''[;]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'COOP_STATUS',
                                                               p_field_value     => 'SP_COOP_STATE_Y',
                                                               p_field_desc      => 'SP_COOP_STATE_DESC_Y');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_7''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_COOP_STATE_Y]'',q''[1]'',q''[]'',q''[SP_COOP_STATE_DESC_Y]'',q''[]'',q''[]'',q''[SP_COOP_STATE_Y]'',,q''[]'',q''[SP_COOP_STATE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_7''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_COOP_STATE_Y]'',q''[1]'',q''[]'',''look_a_supp_111_7'',q''[SP_COOP_STATE_DESC_Y]'',q''[]'',q''[]'',q''[SP_COOP_STATE_Y]'',,q''[]'',q''[SP_COOP_STATE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_cate           VARCHAR2(128);
  v_procate        VARCHAR2(256);
  v_subcate        VARCHAR2(512);
  v_sql            CLOB;
  v_ask_record_id  VARCHAR2(32);
  v_factory_ask_id VARCHAR2(32);
BEGIN
  --获取asscoiate请求参数
  v_ask_record_id := pkg_plat_comm.f_get_rest_val_method_params(p_character => %ass_ask_record_id%,
                                                                p_rtn_type  => 1);

  SELECT MAX(t.factory_ask_id)
    INTO v_factory_ask_id
    FROM scmdata.t_factory_ask t
   WHERE t.ask_record_id = v_ask_record_id
     AND t.company_id = %default_company_id%
   ORDER BY t.create_date DESC;

  v_factory_ask_id := nvl(v_factory_ask_id, :factory_ask_id);

  IF v_factory_ask_id IS NULL THEN
    v_sql := 'SELECT SUPPLIER_INFO_ID      AR_RELA_SUPPLIER_ID_N,
       SUPPLIER_COMPANY_NAME RELA_SUPPLIER_ID_DESC
  FROM SCMDATA.T_SUPPLIER_INFO
 WHERE COMPANY_ID =%DEFAULT_COMPANY_ID%
   AND STATUS = 1';

  ELSIF v_factory_ask_id IS NOT NULL AND :ar_cooperation_model_y = 'OF' THEN
    SELECT listagg(cooperation_classification, ';') within GROUP(ORDER BY 1),
           listagg(a.cooperation_product_cate, ';') within GROUP(ORDER BY 1),
           listagg(a.cooperation_subcategory, ';') within GROUP(ORDER BY 1)
      INTO v_cate, v_procate, v_subcate
      FROM scmdata.t_ask_scope a
     WHERE a.object_id = v_factory_ask_id
       AND a.company_id = %default_company_id%;

    v_sql := q'[SELECT DISTINCT A.SUPPLIER_INFO_ID      AR_RELA_SUPPLIER_ID_N,
       A.SUPPLIER_COMPANY_NAME RELA_SUPPLIER_ID_DESC
  FROM SCMDATA.T_SUPPLIER_INFO A
  INNER JOIN SCMDATA.T_COOP_SCOPE B ON A.SUPPLIER_INFO_ID=B.SUPPLIER_INFO_ID AND A.COMPANY_ID=B.COMPANY_ID
 WHERE A.COMPANY_ID = %default_company_id%
   AND A.pause <> 1
   AND A.STATUS = 1
   AND B.PAUSE = 0
   AND A.COOPERATION_MODEL <> 'OF'
   AND INSTR(';'||']' || v_cate || q'['||';',';'||B.COOP_CLASSIFICATION||';')>0
   AND SCMDATA.INSTR_PRIV(']' || v_procate ||
             q'[', B.COOP_PRODUCT_CATE) >0
   AND SCMDATA.INSTR_PRIV(']' || v_subcate ||
             q'[',B.COOP_SUBCATEGORY) >0 ]';
  END IF;
  @strresult := v_sql;
END;
}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''lookup_a_coop_150_3_0''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_RELA_SUPPLIER_ID_N]'',q''[1]'',q''[0]'',q''[RELA_SUPPLIER_ID_DESC]'',q''[]'',q''[]'',q''[AR_RELA_SUPPLIER_ID_N]'',0,q''[]'',q''[RELA_SUPPLIER_ID_DESC]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''lookup_a_coop_150_3_0''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_RELA_SUPPLIER_ID_N]'',q''[1]'',q''[0]'',''lookup_a_coop_150_3_0'',q''[RELA_SUPPLIER_ID_DESC]'',q''[]'',q''[]'',q''[AR_RELA_SUPPLIER_ID_N]'',0,q''[]'',q''[RELA_SUPPLIER_ID_DESC]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^--czh 重构代码
{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'FA_PRODUCT_TYPE',
                                                               p_field_value     => 'SP_PRODUCT_TYPE_Y',
                                                               p_field_desc      => 'SP_PRODUCT_TYPE_DESC_Y');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_8''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_PRODUCT_TYPE_Y]'',q''[1]'',q''[0]'',q''[SP_PRODUCT_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[SP_PRODUCT_TYPE_Y]'',0,q''[]'',q''[SP_PRODUCT_TYPE_DESC_Y]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_8''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_PRODUCT_TYPE_Y]'',q''[1]'',q''[0]'',''look_a_supp_111_8'',q''[SP_PRODUCT_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[SP_PRODUCT_TYPE_Y]'',0,q''[]'',q''[SP_PRODUCT_TYPE_DESC_Y]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'BRAND_TYPE',
                                                               p_field_value     => 'SP_BRAND_TYPE_N',
                                                               p_field_desc      => 'SP_BRAND_TYPE_DESC_N');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_10''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_BRAND_TYPE_N]'',q''[1]'',q''[]'',q''[SP_BRAND_TYPE_DESC_N]'',q''[]'',q''[]'',q''[SP_BRAND_TYPE_N]'',,q''[]'',q''[SP_BRAND_TYPE_DESC_N]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_10''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_BRAND_TYPE_N]'',q''[1]'',q''[]'',''look_a_supp_111_10'',q''[SP_BRAND_TYPE_DESC_N]'',q''[]'',q''[]'',q''[SP_BRAND_TYPE_N]'',,q''[]'',q''[SP_BRAND_TYPE_DESC_N]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'SUPPLY_TYPE',p_field_value => 'AR_COOPERATION_MODEL_Y',p_field_desc => 'AR_COOP_MODEL_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_121_5''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_COOPERATION_MODEL_Y]'',q''[1]'',q''[]'',q''[AR_COOP_MODEL_DESC_Y]'',q''[]'',q''[]'',q''[AR_COOPERATION_MODEL_Y]'',1,q''[]'',q''[AR_COOP_MODEL_DESC_Y]'',,q''[;]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_121_5''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_COOPERATION_MODEL_Y]'',q''[1]'',q''[]'',''look_a_coop_121_5'',q''[AR_COOP_MODEL_DESC_Y]'',q''[]'',q''[]'',q''[AR_COOPERATION_MODEL_Y]'',1,q''[]'',q''[AR_COOP_MODEL_DESC_Y]'',,q''[;]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT d.dept_name,
       b.avatar,
       a.user_id           flw_order,
       a.company_user_name flw_order_name
  FROM sys_company_user a
 INNER JOIN sys_user b
    ON a.user_id = b.user_id
  LEFT JOIN sys_company_user_dept c
    ON a.user_id = c.user_id
   AND a.company_id = c.company_id
  LEFT JOIN sys_company_dept d
    ON c.company_dept_id = d.company_dept_id
   AND c.company_id = d.company_id
 WHERE a.company_id = %default_company_id%
   AND a.pause = 0
   AND b.pause = 0^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_160_5''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[FLW_ORDER]'',q''[1]'',q''[0]'',q''[FLW_ORDER_NAME]'',q''[DEPT_NAME]'',q''[AVATAR]'',q''[FLW_ORDER]'',1,q''[]'',q''[FLW_ORDER_NAME]'',1,q''[,]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_160_5''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[FLW_ORDER]'',q''[1]'',q''[0]'',''look_a_supp_160_5'',q''[FLW_ORDER_NAME]'',q''[DEPT_NAME]'',q''[AVATAR]'',q''[FLW_ORDER]'',1,q''[]'',q''[FLW_ORDER_NAME]'',1,q''[,]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t1.group_dict_value CONTRACT_TYPE,
       t1.group_dict_name  CONTRACT_TYPE_DESC
  FROM scmdata.sys_group_dict t, scmdata.sys_group_dict t1
 WHERE t.group_dict_id = t1.parent_id
   AND t.group_dict_value = 'CONTRACT_TYPE'
   AND t1.pause = 0
 ORDER BY t1.group_dict_value^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_151_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[CONTRACT_TYPE]'',q''[1]'',q''[]'',q''[CONTRACT_TYPE_DESC]'',q''[]'',q''[]'',q''[CONTRACT_TYPE]'',,q''[]'',q''[CONTRACT_TYPE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_151_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[CONTRACT_TYPE]'',q''[1]'',q''[]'',''look_a_supp_151_2'',q''[CONTRACT_TYPE_DESC]'',q''[]'',q''[]'',q''[CONTRACT_TYPE]'',,q''[]'',q''[CONTRACT_TYPE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select group_dict_value PRODUCTION_MODE,group_dict_name PRODUCTION_MODE_DESC from sys_group_dict where group_dict_type='SUPPLY_TYPE' andgroup_dict_value<>group_dict_type and pause=0^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_2001''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[PRODUCTION_MODE]'',q''[1]'',q''[]'',q''[PRODUCTION_MODE_DESC]'',q''[]'',q''[]'',q''[PRODUCTION_MODE]'',,q''[]'',q''[PRODUCTION_MODE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_2001''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[PRODUCTION_MODE]'',q''[1]'',q''[]'',''look_a_coop_2001'',q''[PRODUCTION_MODE_DESC]'',q''[]'',q''[]'',q''[PRODUCTION_MODE]'',,q''[]'',q''[PRODUCTION_MODE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'COOPERATION_TYPE',p_field_value => 'AR_COOPERATION_TYPE_Y',p_field_desc => 'AR_COOP_TYPE_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''lookup_a_coop_151_0''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_COOPERATION_TYPE_Y]'',q''[1]'',q''[]'',q''[AR_COOP_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_COOPERATION_TYPE_Y]'',,q''[]'',q''[AR_COOP_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''lookup_a_coop_151_0''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_COOPERATION_TYPE_Y]'',q''[1]'',q''[]'',''lookup_a_coop_151_0'',q''[AR_COOP_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_COOPERATION_TYPE_Y]'',,q''[]'',q''[AR_COOP_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^--czh 重构代码
{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := pkg_ask_record_mange.f_query_lookup_com_mnfacturer(p_com_mnfacturer_field => 'COM_MANUFACTURER',p_suffix  => '_DESC');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_150_3_5''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[COM_MANUFACTURER]'',q''[1]'',q''[0]'',q''[COM_MANUFACTURER_DESC]'',q''[]'',q''[]'',q''[COM_MANUFACTURER]'',0,q''[]'',q''[COM_MANUFACTURER_DESC]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_150_3_5''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[COM_MANUFACTURER]'',q''[1]'',q''[0]'',''look_a_coop_150_3_5'',q''[COM_MANUFACTURER_DESC]'',q''[]'',q''[]'',q''[COM_MANUFACTURER]'',0,q''[]'',q''[COM_MANUFACTURER_DESC]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select k.value company_type,k.name company_type_desc from
(select 'a' value,'贸易型' name from dual
union
select 'b' value,'工厂型' name from dual
union
select 'c' value,'工贸一体' name from dual
)k^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_121_6''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[company_type]'',q''[1]'',q''[]'',q''[company_type_desc]'',q''[]'',q''[]'',q''[company_type]'',,q''[]'',q''[company_type_desc]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_121_6''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[company_type]'',q''[1]'',q''[]'',''look_a_coop_121_6'',q''[company_type_desc]'',q''[]'',q''[]'',q''[company_type]'',,q''[]'',q''[company_type_desc]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select 0 PAUSE , '正常' PAUSE_DESC from dual
union all
select 1 PAUSE , '停用' PAUSE_DESC from dual
    ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_g_501_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[PAUSE]'',q''[1]'',q''[]'',q''[PAUSE_DESC]'',q''[]'',q''[]'',q''[PAUSE]'',,q''[]'',q''[PAUSE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_g_501_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[PAUSE]'',q''[1]'',q''[]'',''look_g_501_1'',q''[PAUSE_DESC]'',q''[]'',q''[]'',q''[PAUSE]'',,q''[]'',q''[PAUSE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'COOPERATION_TYPE',p_field_value => 'AR_COOPERATION_TYPE_Y',p_field_desc => 'AR_COOP_TYPE_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''lookup_a_coop_151_0''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_COOPERATION_TYPE_Y]'',q''[1]'',q''[]'',q''[AR_COOP_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_COOPERATION_TYPE_Y]'',,q''[]'',q''[AR_COOP_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''lookup_a_coop_151_0''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_COOPERATION_TYPE_Y]'',q''[1]'',q''[]'',''lookup_a_coop_151_0'',q''[AR_COOP_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_COOPERATION_TYPE_Y]'',,q''[]'',q''[AR_COOP_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'PRODUCT_LINK',p_field_value => 'AR_PRODUCT_LINK_N',p_field_desc => 'AR_PRODUCT_LINK_DESC_N');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_121_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PRODUCT_LINK_N]'',q''[1]'',q''[0]'',q''[AR_PRODUCT_LINK_DESC_N]'',q''[]'',q''[]'',q''[AR_PRODUCT_LINK_N]'',0,q''[]'',q''[AR_PRODUCT_LINK_DESC_N]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_121_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PRODUCT_LINK_N]'',q''[1]'',q''[0]'',''look_a_coop_121_1'',q''[AR_PRODUCT_LINK_DESC_N]'',q''[]'',q''[]'',q''[AR_PRODUCT_LINK_N]'',0,q''[]'',q''[AR_PRODUCT_LINK_DESC_N]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'COST_STEP',
                                                               p_field_value     => 'SP_COST_STEP_N',
                                                               p_field_desc      => 'SP_COST_STEP_DESC_N');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_16''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_COST_STEP_N]'',q''[1]'',q''[]'',q''[SP_COST_STEP_DESC_N]'',q''[]'',q''[]'',q''[SP_COST_STEP_N]'',,q''[]'',q''[SP_COST_STEP_DESC_N]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_16''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_COST_STEP_N]'',q''[1]'',q''[]'',''look_a_supp_111_16'',q''[SP_COST_STEP_DESC_N]'',q''[]'',q''[]'',q''[SP_COST_STEP_N]'',,q''[]'',q''[SP_COST_STEP_DESC_N]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'COST_STEP',
                                                               p_field_value     => 'SP_COST_STEP_N',
                                                               p_field_desc      => 'SP_COST_STEP_DESC_N');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_16''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_COST_STEP_N]'',q''[1]'',q''[]'',q''[SP_COST_STEP_DESC_N]'',q''[]'',q''[]'',q''[SP_COST_STEP_N]'',,q''[]'',q''[SP_COST_STEP_DESC_N]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_16''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_COST_STEP_N]'',q''[1]'',q''[]'',''look_a_supp_111_16'',q''[SP_COST_STEP_DESC_N]'',q''[]'',q''[]'',q''[SP_COST_STEP_N]'',,q''[]'',q''[SP_COST_STEP_DESC_N]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select k.value COOPERATION_BRAND,k.name COOPERATION_BRAND_DESC from
(select 'a' value,'UR' name from dual
union
select 'b' value,'三福' name from dual
union
select 'c' value,'热风' name from dual
union
select 'd' value,'其他' name from dual
)k^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_121_7''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[COOPERATION_BRAND]'',q''[1]'',q''[]'',q''[COOPERATION_BRAND_DESC]'',q''[]'',q''[]'',q''[COOPERATION_BRAND]'',1,q''[]'',q''[COOPERATION_BRAND_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_121_7''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[COOPERATION_BRAND]'',q''[1]'',q''[]'',''look_a_coop_121_7'',q''[COOPERATION_BRAND_DESC]'',q''[]'',q''[]'',q''[COOPERATION_BRAND]'',1,q''[]'',q''[COOPERATION_BRAND_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t1.group_dict_value PAY_TYPE,
       t1.group_dict_name  PAY_TYPE_SP
  FROM scmdata.sys_group_dict t, scmdata.sys_group_dict t1
 WHERE t.group_dict_id = t1.parent_id
   AND t.group_dict_value = 'PAY_METHOD'
   AND t1.pause = 0
 ORDER BY t1.group_dict_value^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''lookup_a_supp_111_7''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[PAY_TYPE]'',q''[1]'',q''[]'',q''[PAY_TYPE_SP]'',q''[]'',q''[]'',q''[PAY_TYPE]'',,q''[]'',q''[PAY_TYPE_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''lookup_a_supp_111_7''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[PAY_TYPE]'',q''[1]'',q''[]'',''lookup_a_supp_111_7'',q''[PAY_TYPE_SP]'',q''[]'',q''[]'',q''[PAY_TYPE]'',,q''[]'',q''[PAY_TYPE_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^--czh 重构代码
{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := pkg_ask_record_mange.f_query_company_type_looksql(p_company_type_field => 'COMPANY_TYPE', p_suffix =>'_DESC');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_150_3_3''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[COMPANY_TYPE]'',q''[1]'',q''[0]'',q''[COMPANY_TYPE_DESC]'',q''[]'',q''[]'',q''[COMPANY_TYPE]'',0,q''[]'',q''[COMPANY_TYPE_DESC]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_150_3_3''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[COMPANY_TYPE]'',q''[1]'',q''[0]'',''look_a_coop_150_3_3'',q''[COMPANY_TYPE_DESC]'',q''[]'',q''[]'',q''[COMPANY_TYPE]'',0,q''[]'',q''[COMPANY_TYPE_DESC]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t1.group_dict_value SETTLEMENT_TYPE,
       t1.group_dict_name  SETTLEMENT_TYPE_SP
  FROM scmdata.sys_group_dict t, scmdata.sys_group_dict t1
 WHERE t.group_dict_id = t1.parent_id
   AND t.group_dict_value = 'SETTLE_METHOD'
   AND t1.pause = 0
 ORDER BY t1.group_dict_value^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''lookup_a_supp_111_8''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SETTLEMENT_TYPE]'',q''[1]'',q''[]'',q''[SETTLEMENT_TYPE_SP]'',q''[]'',q''[]'',q''[SETTLEMENT_TYPE]'',,q''[]'',q''[SETTLEMENT_TYPE_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''lookup_a_supp_111_8''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SETTLEMENT_TYPE]'',q''[1]'',q''[]'',''lookup_a_supp_111_8'',q''[SETTLEMENT_TYPE_SP]'',q''[]'',q''[]'',q''[SETTLEMENT_TYPE]'',,q''[]'',q''[SETTLEMENT_TYPE_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select group_dict_value FACTRORY_ASK_FLOW_STATUS,group_dict_name FLOW_STATUS_DESC from sys_group_dict where group_dict_type='FACTORY_ASK_FLOW' and group_dict_value<>group_dict_type and pause =0^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_2004''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[FACTRORY_ASK_FLOW_STATUS]'',q''[1]'',q''[]'',q''[FLOW_STATUS_DESC]'',q''[]'',q''[]'',q''[FACTRORY_ASK_FLOW_STATUS]'',,q''[]'',q''[FLOW_STATUS_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_2004''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[FACTRORY_ASK_FLOW_STATUS]'',q''[1]'',q''[]'',''look_a_coop_2004'',q''[FLOW_STATUS_DESC]'',q''[]'',q''[]'',q''[FACTRORY_ASK_FLOW_STATUS]'',,q''[]'',q''[FLOW_STATUS_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select group_dict_value FACTRORY_ASK_FLOW_STATUS,group_dict_name FLOW_STATUS_DESC from sys_group_dict where group_dict_type='FACTORY_ASK_FLOW' and group_dict_value<>group_dict_type and pause =0^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_2004''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[FACTRORY_ASK_FLOW_STATUS]'',q''[1]'',q''[]'',q''[FLOW_STATUS_DESC]'',q''[]'',q''[]'',q''[FACTRORY_ASK_FLOW_STATUS]'',,q''[]'',q''[FLOW_STATUS_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_2004''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[FACTRORY_ASK_FLOW_STATUS]'',q''[1]'',q''[]'',''look_a_coop_2004'',q''[FLOW_STATUS_DESC]'',q''[]'',q''[]'',q''[FACTRORY_ASK_FLOW_STATUS]'',,q''[]'',q''[FLOW_STATUS_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select 0 FACTORY_ASK_TYPE,'不验厂' FACTORY_ASK_TYPE_DESC from dual
union
select 1 FACTORY_ASK_TYPE,'内部验厂' FACTORY_ASK_TYPE_DESC from dual
union
select 2 FACTORY_ASK_TYPE,'第三方验厂' FACTORY_ASK_TYPE_DESC from dual^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_2003''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[]'',q''[1]'',q''[]'',q''[FACTORY_ASK_TYPE_DESC]'',q''[]'',q''[]'',q''[FACTORY_ASK_TYPE]'',,q''[]'',q''[FACTORY_ASK_TYPE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_2003''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[]'',q''[1]'',q''[]'',''look_a_coop_2003'',q''[FACTORY_ASK_TYPE_DESC]'',q''[]'',q''[]'',q''[FACTORY_ASK_TYPE]'',,q''[]'',q''[FACTORY_ASK_TYPE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT p.group_dict_value STATUS, p.group_dict_name SP_STATUS_DESC
  FROM scmdata.sys_group_dict p
 WHERE p.group_dict_type = 'CSUPP_STATUS'
   AND p.parent_id IS NOT NULL^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_110''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[STATUS]'',q''[1]'',q''[]'',q''[SP_STATUS_DESC]'',q''[]'',q''[]'',q''[STATUS]'',,q''[]'',q''[SP_STATUS_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_110''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[STATUS]'',q''[1]'',q''[]'',''look_a_supp_110'',q''[SP_STATUS_DESC]'',q''[]'',q''[]'',q''[STATUS]'',,q''[]'',q''[SP_STATUS_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'PRODUCT_LINK',p_field_value => 'AR_PRODUCT_LINK_N',p_field_desc => 'AR_PRODUCT_LINK_DESC_N');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_121_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PRODUCT_LINK_N]'',q''[1]'',q''[0]'',q''[AR_PRODUCT_LINK_DESC_N]'',q''[]'',q''[]'',q''[AR_PRODUCT_LINK_N]'',0,q''[]'',q''[AR_PRODUCT_LINK_DESC_N]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_121_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PRODUCT_LINK_N]'',q''[1]'',q''[0]'',''look_a_coop_121_1'',q''[AR_PRODUCT_LINK_DESC_N]'',q''[]'',q''[]'',q''[AR_PRODUCT_LINK_N]'',0,q''[]'',q''[AR_PRODUCT_LINK_DESC_N]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t.group_name group_name_desc, t.group_config_id group_name
  FROM scmdata.t_supplier_group_config t
 WHERE t.company_id = %default_company_id%^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_151''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[GROUP_NAME]'',q''[1]'',q''[]'',q''[GROUP_NAME_DESC]'',q''[]'',q''[]'',q''[GROUP_NAME]'',,q''[]'',q''[GROUP_NAME_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_151''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[GROUP_NAME]'',q''[1]'',q''[]'',''look_a_supp_151'',q''[GROUP_NAME_DESC]'',q''[]'',q''[]'',q''[GROUP_NAME]'',,q''[]'',q''[GROUP_NAME_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select group_dict_value COOPERATION_MODEL,group_dict_name COOPERATION_MODEL_DESC from sys_group_dict where group_dict_type='CPMODE_TYPE' and group_dict_value<>group_dict_type and pause =0 ORDER BY group_dict_sort,group_dict_value^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_2002''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[COOPERATION_MODEL]'',q''[1]'',q''[]'',q''[COOPERATION_MODEL_DESC]'',q''[]'',q''[]'',q''[COOPERATION_MODEL]'',,q''[]'',q''[COOPERATION_MODEL_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_2002''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[COOPERATION_MODEL]'',q''[1]'',q''[]'',''look_a_coop_2002'',q''[COOPERATION_MODEL_DESC]'',q''[]'',q''[]'',q''[COOPERATION_MODEL]'',,q''[]'',q''[COOPERATION_MODEL_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'PRODUCT_LINK',p_field_value => 'AR_PRODUCT_LINK_N',p_field_desc => 'AR_PRODUCT_LINK_DESC_N');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_121_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PRODUCT_LINK_N]'',q''[1]'',q''[0]'',q''[AR_PRODUCT_LINK_DESC_N]'',q''[]'',q''[]'',q''[AR_PRODUCT_LINK_N]'',0,q''[]'',q''[AR_PRODUCT_LINK_DESC_N]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_121_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PRODUCT_LINK_N]'',q''[1]'',q''[0]'',''look_a_coop_121_1'',q''[AR_PRODUCT_LINK_DESC_N]'',q''[]'',q''[]'',q''[AR_PRODUCT_LINK_N]'',0,q''[]'',q''[AR_PRODUCT_LINK_DESC_N]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'FABRIC_PURCHASE_CAP',
                                                               p_field_value     => 'SP_FABRIC_PURCHASE_CAP_Y',
                                                               p_field_desc      => 'SP_FABRIC_PUR_CAP_DESC_Y');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_14''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_FABRIC_PURCHASE_CAP_Y]'',q''[1]'',q''[]'',q''[SP_FABRIC_PUR_CAP_DESC_Y]'',q''[]'',q''[]'',q''[SP_FABRIC_PURCHASE_CAP_Y]'',,q''[]'',q''[SP_FABRIC_PUR_CAP_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_14''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_FABRIC_PURCHASE_CAP_Y]'',q''[1]'',q''[]'',''look_a_supp_111_14'',q''[SP_FABRIC_PUR_CAP_DESC_Y]'',q''[]'',q''[]'',q''[SP_FABRIC_PURCHASE_CAP_Y]'',,q''[]'',q''[SP_FABRIC_PUR_CAP_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'FABRIC_CHECK_CAP',
                                                               p_field_value     => 'SP_FABRIC_CHECK_CAP_Y',
                                                               p_field_desc      => 'SP_FABRIC_CHECK_CAP_DESC_Y');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_15''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_FABRIC_CHECK_CAP_Y]'',q''[1]'',q''[]'',q''[SP_FABRIC_CHECK_CAP_DESC_Y]'',q''[]'',q''[]'',q''[SP_FABRIC_CHECK_CAP_Y]'',,q''[]'',q''[SP_FABRIC_CHECK_CAP_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_15''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_FABRIC_CHECK_CAP_Y]'',q''[1]'',q''[]'',''look_a_supp_111_15'',q''[SP_FABRIC_CHECK_CAP_DESC_Y]'',q''[]'',q''[]'',q''[SP_FABRIC_CHECK_CAP_Y]'',,q''[]'',q''[SP_FABRIC_CHECK_CAP_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE v_sql CLOB; BEGIN v_sql := pkg_ask_record_mange.f_query_supply_type_looksql(p_supply_type_field => 'FACTORY_COOP_MODEL',p_suffix => '_DESC');  @strresult := v_sql; END; }^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_150_3_6''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[FACTORY_COOP_MODEL]'',q''[1]'',q''[0]'',q''[FACTORY_COOP_MODEL_DESC]'',q''[]'',q''[]'',q''[FACTORY_COOP_MODEL]'',0,q''[]'',q''[FACTORY_COOP_MODEL_DESC]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_150_3_6''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[FACTORY_COOP_MODEL]'',q''[1]'',q''[0]'',''look_a_coop_150_3_6'',q''[FACTORY_COOP_MODEL_DESC]'',q''[]'',q''[]'',q''[FACTORY_COOP_MODEL]'',0,q''[]'',q''[FACTORY_COOP_MODEL_DESC]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select group_dict_value PRODUCTION_MODE,group_dict_name PRODUCTION_MODE_DESC from sys_group_dict where group_dict_type='SUPPLY_TYPE' andgroup_dict_value<>group_dict_type and pause=0^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_2001''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[PRODUCTION_MODE]'',q''[1]'',q''[]'',q''[PRODUCTION_MODE_DESC]'',q''[]'',q''[]'',q''[PRODUCTION_MODE]'',,q''[]'',q''[PRODUCTION_MODE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_2001''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[PRODUCTION_MODE]'',q''[1]'',q''[]'',''look_a_coop_2001'',q''[PRODUCTION_MODE_DESC]'',q''[]'',q''[]'',q''[PRODUCTION_MODE]'',,q''[]'',q''[PRODUCTION_MODE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'COMPANY_TYPE',p_field_value => 'AR_COMPANY_TYPE_Y',p_field_desc => 'AR_COMPANY_TYPE_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_121_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_COMPANY_TYPE_Y]'',q''[1]'',q''[0]'',q''[AR_COMPANY_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_COMPANY_TYPE_Y]'',0,q''[]'',q''[AR_COMPANY_TYPE_DESC_Y]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_121_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_COMPANY_TYPE_Y]'',q''[1]'',q''[0]'',''look_a_coop_121_2'',q''[AR_COMPANY_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_COMPANY_TYPE_Y]'',0,q''[]'',q''[AR_COMPANY_TYPE_DESC_Y]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select group_dict_value FACTRORY_ASK_FLOW_STATUS,group_dict_name FLOW_STATUS_DESC from sys_group_dict where group_dict_type='FACTORY_ASK_FLOW' and group_dict_value<>group_dict_type and pause =0^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_2004''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[FACTRORY_ASK_FLOW_STATUS]'',q''[1]'',q''[]'',q''[FLOW_STATUS_DESC]'',q''[]'',q''[]'',q''[FACTRORY_ASK_FLOW_STATUS]'',,q''[]'',q''[FLOW_STATUS_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_2004''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[FACTRORY_ASK_FLOW_STATUS]'',q''[1]'',q''[]'',''look_a_coop_2004'',q''[FLOW_STATUS_DESC]'',q''[]'',q''[]'',q''[FACTRORY_ASK_FLOW_STATUS]'',,q''[]'',q''[FLOW_STATUS_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'SUPPLY_TYPE',p_field_value => 'AR_COOPERATION_MODEL_Y',p_field_desc => 'AR_COOP_MODEL_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_121_5''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_COOPERATION_MODEL_Y]'',q''[1]'',q''[]'',q''[AR_COOP_MODEL_DESC_Y]'',q''[]'',q''[]'',q''[AR_COOPERATION_MODEL_Y]'',1,q''[]'',q''[AR_COOP_MODEL_DESC_Y]'',,q''[;]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_121_5''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_COOPERATION_MODEL_Y]'',q''[1]'',q''[]'',''look_a_coop_121_5'',q''[AR_COOP_MODEL_DESC_Y]'',q''[]'',q''[]'',q''[AR_COOPERATION_MODEL_Y]'',1,q''[]'',q''[AR_COOP_MODEL_DESC_Y]'',,q''[;]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select group_dict_value PRODUCTION_MODE,group_dict_name PRODUCTION_MODE_DESC from sys_group_dict where group_dict_type='SUPPLY_TYPE' and parent_id is not null and pause=0^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_121_4''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[PRODUCTION_MODE]'',q''[1]'',q''[]'',q''[PRODUCTION_MODE_DESC]'',q''[]'',q''[]'',q''[PRODUCTION_MODE]'',,q''[]'',q''[PRODUCTION_MODE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_121_4''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[PRODUCTION_MODE]'',q''[1]'',q''[]'',''look_a_coop_121_4'',q''[PRODUCTION_MODE_DESC]'',q''[]'',q''[]'',q''[PRODUCTION_MODE]'',,q''[]'',q''[PRODUCTION_MODE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select 0 PAUSE , '正常' PAUSE_DESC from dual
union all
select 1 PAUSE , '停用' PAUSE_DESC from dual
    ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_g_501_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[PAUSE]'',q''[1]'',q''[]'',q''[PAUSE_DESC]'',q''[]'',q''[]'',q''[PAUSE]'',,q''[]'',q''[PAUSE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_g_501_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[PAUSE]'',q''[1]'',q''[]'',''look_g_501_1'',q''[PAUSE_DESC]'',q''[]'',q''[]'',q''[PAUSE]'',,q''[]'',q''[PAUSE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'COOPERATION_TYPE',p_field_value => 'AR_COOPERATION_TYPE_Y',p_field_desc => 'AR_COOP_TYPE_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''lookup_a_coop_151_0''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_COOPERATION_TYPE_Y]'',q''[1]'',q''[]'',q''[AR_COOP_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_COOPERATION_TYPE_Y]'',,q''[]'',q''[AR_COOP_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''lookup_a_coop_151_0''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_COOPERATION_TYPE_Y]'',q''[1]'',q''[]'',''lookup_a_coop_151_0'',q''[AR_COOP_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_COOPERATION_TYPE_Y]'',,q''[]'',q''[AR_COOP_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select group_dict_value COOPERATION_MODEL,group_dict_name COOPERATION_MODEL_DESC from sys_group_dict where group_dict_type='CPMODE_TYPE' and group_dict_value<>group_dict_type and pause =0 ORDER BY group_dict_sort,group_dict_value^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_2002''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[COOPERATION_MODEL]'',q''[1]'',q''[]'',q''[COOPERATION_MODEL_DESC]'',q''[]'',q''[]'',q''[COOPERATION_MODEL]'',,q''[]'',q''[COOPERATION_MODEL_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_2002''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[COOPERATION_MODEL]'',q''[1]'',q''[]'',''look_a_coop_2002'',q''[COOPERATION_MODEL_DESC]'',q''[]'',q''[]'',q''[COOPERATION_MODEL]'',,q''[]'',q''[COOPERATION_MODEL_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t1.group_dict_value production_mode,
       t1.group_dict_name  production_mode_sp
  FROM scmdata.sys_group_dict t, scmdata.sys_group_dict t1
 WHERE t.group_dict_id = t1.parent_id
   AND t.group_dict_value = 'CPMODE_TYPE'
   AND t1.pause = 0
 ORDER BY t1.group_dict_value^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_6''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[PRODUCTION_MODE]'',q''[1]'',q''[]'',q''[PRODUCTION_MODE_SP]'',q''[]'',q''[]'',q''[PRODUCTION_MODE]'',,q''[]'',q''[PRODUCTION_MODE_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_6''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[PRODUCTION_MODE]'',q''[1]'',q''[]'',''look_a_supp_111_6'',q''[PRODUCTION_MODE_SP]'',q''[]'',q''[]'',q''[PRODUCTION_MODE]'',,q''[]'',q''[PRODUCTION_MODE_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select 0 FACTORY_ASK_TYPE,'不验厂' FACTORY_ASK_TYPE_DESC from dual
union
select 1 FACTORY_ASK_TYPE,'内部验厂' FACTORY_ASK_TYPE_DESC from dual
union
select 2 FACTORY_ASK_TYPE,'第三方验厂' FACTORY_ASK_TYPE_DESC from dual^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_2003''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[]'',q''[1]'',q''[]'',q''[FACTORY_ASK_TYPE_DESC]'',q''[]'',q''[]'',q''[FACTORY_ASK_TYPE]'',,q''[]'',q''[FACTORY_ASK_TYPE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_2003''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[]'',q''[1]'',q''[]'',''look_a_coop_2003'',q''[FACTORY_ASK_TYPE_DESC]'',q''[]'',q''[]'',q''[FACTORY_ASK_TYPE]'',,q''[]'',q''[FACTORY_ASK_TYPE_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'COMPANY_TYPE',
                                                               p_field_value     => 'SP_COMPANY_TYPE_Y',
                                                               p_field_desc      => 'SP_COMPANY_TYPE_DESC_Y');
  @strresult := v_sql;
END;
}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_COMPANY_TYPE_Y]'',q''[1]'',q''[]'',q''[SP_COMPANY_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[SP_COMPANY_TYPE_Y]'',0,q''[]'',q''[SP_COMPANY_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_COMPANY_TYPE_Y]'',q''[1]'',q''[]'',''look_a_supp_111_1'',q''[SP_COMPANY_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[SP_COMPANY_TYPE_Y]'',0,q''[]'',q''[SP_COMPANY_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'COOPERATION_TYPE',
                                                               p_field_value     => 'SP_COOPERATION_TYPE_Y',
                                                               p_field_desc      => 'SP_COOPERATION_TYPE_DESC_Y');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_4''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_COOPERATION_TYPE_Y]'',q''[1]'',q''[]'',q''[SP_COOPERATION_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[SP_COOPERATION_TYPE_Y]'',,q''[]'',q''[SP_COOPERATION_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_4''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_COOPERATION_TYPE_Y]'',q''[1]'',q''[]'',''look_a_supp_111_4'',q''[SP_COOPERATION_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[SP_COOPERATION_TYPE_Y]'',,q''[]'',q''[SP_COOPERATION_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t1.group_dict_value taxpayer, t1.group_dict_name taxpayer_desc
  FROM scmdata.sys_group_dict t, scmdata.sys_group_dict t1
 WHERE t.group_dict_id = t1.parent_id
   AND t.group_dict_value = 'TAXPAYER_TYPE'
   AND t1.pause = 0
 ORDER BY t1.group_dict_value^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[TAXPAYER]'',q''[1]'',q''[]'',q''[TAXPAYER_DESC]'',q''[]'',q''[]'',q''[TAXPAYER]'',,q''[]'',q''[TAXPAYER_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[TAXPAYER]'',q''[1]'',q''[]'',''look_a_supp_111_2'',q''[TAXPAYER_DESC]'',q''[]'',q''[]'',q''[TAXPAYER]'',,q''[]'',q''[TAXPAYER_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'COOPERATION_TYPE',
                                                               p_field_value     => 'SP_COOPERATION_TYPE_Y',
                                                               p_field_desc      => 'SP_COOPERATION_TYPE_DESC_Y');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_4''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_COOPERATION_TYPE_Y]'',q''[1]'',q''[]'',q''[SP_COOPERATION_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[SP_COOPERATION_TYPE_Y]'',,q''[]'',q''[SP_COOPERATION_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_4''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_COOPERATION_TYPE_Y]'',q''[1]'',q''[]'',''look_a_supp_111_4'',q''[SP_COOPERATION_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[SP_COOPERATION_TYPE_Y]'',,q''[]'',q''[SP_COOPERATION_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^--czh 重构代码
{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := pkg_ask_record_mange.f_query_supply_type_looksql(p_supply_type_field => 'COOPERATION_MODEL',p_suffix => '_DESC');
  @strresult := v_sql;
END;}

--原有逻辑
/*
SELECT GROUP_DICT_VALUE COOPERATION_MODEL,
       GROUP_DICT_NAME  COOPERATION_MODEL_DESC
  FROM SCMDATA.SYS_GROUP_DICT
 WHERE GROUP_DICT_TYPE = 'SUPPLY_TYPE'
   AND GROUP_DICT_VALUE != 'SUPPLY_TYPE'
ORDER BY group_dict_sort,group_dict_value*/^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''coop_model''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[COOPERATION_MODEL]'',q''[1]'',q''[0]'',q''[COOPERATION_MODEL_DESC]'',q''[]'',q''[]'',q''[COOPERATION_MODEL]'',1,q''[]'',q''[COOPERATION_MODEL_DESC]'',,q''[;]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''coop_model''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[COOPERATION_MODEL]'',q''[1]'',q''[0]'',''coop_model'',q''[COOPERATION_MODEL_DESC]'',q''[]'',q''[]'',q''[COOPERATION_MODEL]'',1,q''[]'',q''[COOPERATION_MODEL_DESC]'',,q''[;]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT p.group_dict_value bind_status, p.group_dict_name bind_status_sp
  FROM scmdata.sys_group_dict p
 WHERE p.group_dict_type = 'BIND_STATUS_SP'
   AND p.parent_id IS NOT NULL^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_120_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[BIND_STATUS]'',q''[1]'',q''[]'',q''[BIND_STATUS_SP]'',q''[]'',q''[]'',q''[BIND_STATUS]'',,q''[]'',q''[BIND_STATUS_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_120_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[BIND_STATUS]'',q''[1]'',q''[]'',''look_a_supp_120_1'',q''[BIND_STATUS_SP]'',q''[]'',q''[]'',q''[BIND_STATUS]'',,q''[]'',q''[BIND_STATUS_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^--czh 重构代码
{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := pkg_ask_record_mange.f_query_supply_type_looksql(p_supply_type_field => 'COOPERATION_MODEL',p_suffix => '_DESC');
  @strresult := v_sql;
END;}

--原有逻辑
/*
SELECT GROUP_DICT_VALUE COOPERATION_MODEL,
       GROUP_DICT_NAME  COOPERATION_MODEL_DESC
  FROM SCMDATA.SYS_GROUP_DICT
 WHERE GROUP_DICT_TYPE = 'SUPPLY_TYPE'
   AND GROUP_DICT_VALUE != 'SUPPLY_TYPE'
ORDER BY group_dict_sort,group_dict_value*/^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''coop_model''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[COOPERATION_MODEL]'',q''[1]'',q''[0]'',q''[COOPERATION_MODEL_DESC]'',q''[]'',q''[]'',q''[COOPERATION_MODEL]'',1,q''[]'',q''[COOPERATION_MODEL_DESC]'',,q''[;]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''coop_model''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[COOPERATION_MODEL]'',q''[1]'',q''[0]'',''coop_model'',q''[COOPERATION_MODEL_DESC]'',q''[]'',q''[]'',q''[COOPERATION_MODEL]'',1,q''[]'',q''[COOPERATION_MODEL_DESC]'',,q''[;]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^--czh 重构代码
{declare v_sql CLOB;
BEGIN
  v_sql      := pkg_supplier_info.f_query_coop_status_looksql(p_coop_status_field => 'COOP_STATUS',
                                                              p_suffix            => '_DESC');
  @strresult := v_sql;
END;
}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_160''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[COOP_STATUS]'',q''[1]'',q''[]'',q''[COOP_STATUS_DESC]'',q''[]'',q''[]'',q''[COOP_STATUS]'',,q''[]'',q''[COOP_STATUS_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_160''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[COOP_STATUS]'',q''[1]'',q''[]'',''look_a_supp_160'',q''[COOP_STATUS_DESC]'',q''[]'',q''[]'',q''[COOP_STATUS]'',,q''[]'',q''[COOP_STATUS_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^select group_dict_value FACTRORY_ASK_FLOW_STATUS,group_dict_name FLOW_STATUS_DESC from sys_group_dict where group_dict_type='FACTORY_ASK_FLOW' and group_dict_value<>group_dict_type and pause =0^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_2004''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[FACTRORY_ASK_FLOW_STATUS]'',q''[1]'',q''[]'',q''[FLOW_STATUS_DESC]'',q''[]'',q''[]'',q''[FACTRORY_ASK_FLOW_STATUS]'',,q''[]'',q''[FLOW_STATUS_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_2004''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[FACTRORY_ASK_FLOW_STATUS]'',q''[1]'',q''[]'',''look_a_coop_2004'',q''[FLOW_STATUS_DESC]'',q''[]'',q''[]'',q''[FACTRORY_ASK_FLOW_STATUS]'',,q''[]'',q''[FLOW_STATUS_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT p.group_dict_value bind_status, p.group_dict_name bind_status_sp
  FROM scmdata.sys_group_dict p
 WHERE p.group_dict_type = 'BIND_STATUS_SP'
   AND p.parent_id IS NOT NULL^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_120_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[BIND_STATUS]'',q''[1]'',q''[]'',q''[BIND_STATUS_SP]'',q''[]'',q''[]'',q''[BIND_STATUS]'',,q''[]'',q''[BIND_STATUS_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_120_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[BIND_STATUS]'',q''[1]'',q''[]'',''look_a_supp_120_1'',q''[BIND_STATUS_SP]'',q''[]'',q''[]'',q''[BIND_STATUS]'',,q''[]'',q''[BIND_STATUS_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'COMPANY_TYPE',
                                                               p_field_value     => 'SP_COMPANY_TYPE_Y',
                                                               p_field_desc      => 'SP_COMPANY_TYPE_DESC_Y');
  @strresult := v_sql;
END;
}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_COMPANY_TYPE_Y]'',q''[1]'',q''[]'',q''[SP_COMPANY_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[SP_COMPANY_TYPE_Y]'',0,q''[]'',q''[SP_COMPANY_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_COMPANY_TYPE_Y]'',q''[1]'',q''[]'',''look_a_supp_111_1'',q''[SP_COMPANY_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[SP_COMPANY_TYPE_Y]'',0,q''[]'',q''[SP_COMPANY_TYPE_DESC_Y]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'SUPPLY_TYPE',
                                                               p_field_value     => 'SP_COOPERATION_MODEL_Y',
                                                               p_field_desc      => 'SP_COOPERATION_MODEL_DESC_Y');
  @strresult := v_sql;
END;
} ^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_5''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_COOPERATION_MODEL_Y]'',q''[1]'',q''[0]'',q''[SP_COOPERATION_MODEL_DESC_Y]'',q''[]'',q''[]'',q''[SP_COOPERATION_MODEL_Y]'',1,q''[]'',q''[SP_COOPERATION_MODEL_DESC_Y]'',,q''[;]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_5''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_COOPERATION_MODEL_Y]'',q''[1]'',q''[0]'',''look_a_supp_111_5'',q''[SP_COOPERATION_MODEL_DESC_Y]'',q''[]'',q''[]'',q''[SP_COOPERATION_MODEL_Y]'',1,q''[]'',q''[SP_COOPERATION_MODEL_DESC_Y]'',,q''[;]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t1.group_dict_value cooperation_method,
       t1.group_dict_name  cooperation_method_sp
  FROM scmdata.sys_group_dict t, scmdata.sys_group_dict t1
 WHERE t.group_dict_id = t1.parent_id
   AND t.group_dict_value = 'COOP_METHOD'
   AND t1.pause = 0
 ORDER BY t1.group_dict_value^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_3''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[COOPERATION_METHOD]'',q''[1]'',q''[]'',q''[COOPERATION_METHOD_SP]'',q''[]'',q''[]'',q''[COOPERATION_METHOD]'',,q''[]'',q''[COOPERATION_METHOD_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_3''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[COOPERATION_METHOD]'',q''[1]'',q''[]'',''look_a_supp_111_3'',q''[COOPERATION_METHOD_SP]'',q''[]'',q''[]'',q''[COOPERATION_METHOD]'',,q''[]'',q''[COOPERATION_METHOD_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t1.group_dict_value cooperation_method,
       t1.group_dict_name  cooperation_method_sp
  FROM scmdata.sys_group_dict t, scmdata.sys_group_dict t1
 WHERE t.group_dict_id = t1.parent_id
   AND t.group_dict_value = 'COOP_METHOD'
   AND t1.pause = 0
 ORDER BY t1.group_dict_value^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_3''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[COOPERATION_METHOD]'',q''[1]'',q''[]'',q''[COOPERATION_METHOD_SP]'',q''[]'',q''[]'',q''[COOPERATION_METHOD]'',,q''[]'',q''[COOPERATION_METHOD_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_3''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[COOPERATION_METHOD]'',q''[1]'',q''[]'',''look_a_supp_111_3'',q''[COOPERATION_METHOD_SP]'',q''[]'',q''[]'',q''[COOPERATION_METHOD]'',,q''[]'',q''[COOPERATION_METHOD_SP]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t.group_name group_name_desc, t.group_config_id group_name
  FROM scmdata.t_supplier_group_config t
 WHERE t.company_id = %default_company_id%
   AND t.pause = 1^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_161''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[GROUP_NAME]'',q''[1]'',q''[]'',q''[GROUP_NAME_DESC]'',q''[]'',q''[]'',q''[GROUP_NAME]'',,q''[]'',q''[GROUP_NAME_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_161''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[GROUP_NAME]'',q''[1]'',q''[]'',''look_a_supp_161'',q''[GROUP_NAME_DESC]'',q''[]'',q''[]'',q''[GROUP_NAME]'',,q''[]'',q''[GROUP_NAME_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'PATTERN_CAP',p_field_value => 'AR_PATTERN_CAP_Y',p_field_desc => 'AR_PATTERN_CAP_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_7''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PATTERN_CAP_Y]'',q''[1]'',q''[]'',q''[AR_PATTERN_CAP_DESC_Y]'',q''[]'',q''[]'',q''[AR_PATTERN_CAP_Y]'',0,q''[]'',q''[AR_PATTERN_CAP_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_7''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PATTERN_CAP_Y]'',q''[1]'',q''[]'',''look_a_coop_151_7'',q''[AR_PATTERN_CAP_DESC_Y]'',q''[]'',q''[]'',q''[AR_PATTERN_CAP_Y]'',0,q''[]'',q''[AR_PATTERN_CAP_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'PAY_TERM',p_field_value => 'AR_PAY_TERM_N',p_field_desc => 'AR_PAY_TERM_DESC_N');
  @strresult := v_sql;
END;}

/*{DECLARE
  v_sql CLOB;
  v_ask_record_id varchar2(32) := :ask_record_id;
BEGIN
  IF :ar_cooperation_model_y IS NULL OR :ar_cooperation_model_y = 'OF' THEN
    v_sql := 'SELECT NULL AR_PAY_TERM_N, NULL AR_PAY_TERM_DESC_N FROM DUAL';
  ELSE
    v_sql := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'PAY_TERM',
                                                            p_field_value     => 'AR_PAY_TERM_N',
                                                            p_field_desc      => 'AR_PAY_TERM_DESC_N');
  END IF;
  @strresult := v_sql;
END;
}*/^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PAY_TERM_N]'',q''[1]'',q''[]'',q''[AR_PAY_TERM_DESC_N]'',q''[]'',q''[]'',q''[AR_PAY_TERM_N]'',0,q''[]'',q''[AR_PAY_TERM_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PAY_TERM_N]'',q''[1]'',q''[]'',''look_a_coop_151_2'',q''[AR_PAY_TERM_DESC_N]'',q''[]'',q''[]'',q''[AR_PAY_TERM_N]'',0,q''[]'',q''[AR_PAY_TERM_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'FABRIC_PURCHASE_CAP',p_field_value => 'AR_FABRIC_PURCHASE_CAP_Y',p_field_desc => 'AR_FABRIC_PUR_CAP_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_8''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_FABRIC_PURCHASE_CAP_Y]'',q''[1]'',q''[]'',q''[AR_FABRIC_PUR_CAP_DESC_Y]'',q''[]'',q''[]'',q''[AR_FABRIC_PURCHASE_CAP_Y]'',0,q''[]'',q''[AR_FABRIC_PUR_CAP_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_8''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_FABRIC_PURCHASE_CAP_Y]'',q''[1]'',q''[]'',''look_a_coop_151_8'',q''[AR_FABRIC_PUR_CAP_DESC_Y]'',q''[]'',q''[]'',q''[AR_FABRIC_PURCHASE_CAP_Y]'',0,q''[]'',q''[AR_FABRIC_PUR_CAP_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'FABRIC_PURCHASE_CAP',p_field_value => 'AR_FABRIC_PURCHASE_CAP_Y',p_field_desc => 'AR_FABRIC_PUR_CAP_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_8''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_FABRIC_PURCHASE_CAP_Y]'',q''[1]'',q''[]'',q''[AR_FABRIC_PUR_CAP_DESC_Y]'',q''[]'',q''[]'',q''[AR_FABRIC_PURCHASE_CAP_Y]'',0,q''[]'',q''[AR_FABRIC_PUR_CAP_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_8''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_FABRIC_PURCHASE_CAP_Y]'',q''[1]'',q''[]'',''look_a_coop_151_8'',q''[AR_FABRIC_PUR_CAP_DESC_Y]'',q''[]'',q''[]'',q''[AR_FABRIC_PURCHASE_CAP_Y]'',0,q''[]'',q''[AR_FABRIC_PUR_CAP_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t.group_name group_name_desc, t.group_config_id group_name
  FROM scmdata.t_supplier_group_config t
 WHERE t.company_id = %default_company_id%
   AND t.pause = 1^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_161''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[GROUP_NAME]'',q''[1]'',q''[]'',q''[GROUP_NAME_DESC]'',q''[]'',q''[]'',q''[GROUP_NAME]'',,q''[]'',q''[GROUP_NAME_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_161''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[GROUP_NAME]'',q''[1]'',q''[]'',''look_a_supp_161'',q''[GROUP_NAME_DESC]'',q''[]'',q''[]'',q''[GROUP_NAME]'',,q''[]'',q''[GROUP_NAME_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  sql1 VARCHAR2(3000);
BEGIN
  sql1 := 'SELECT a.villid ar_company_vill_y, a.vill ar_company_vill_desc_y FROM scmdata.dic_village a';
  IF :company_county IS NOT NULL THEN
    sql1 := 'SELECT a.villid ar_company_vill_y, a.vill ar_company_vill_desc_y
  FROM scmdata.dic_village a
 INNER JOIN scmdata.dic_county b
    ON a.countyid = b.countyid
 WHERE a.countyid = :company_county
   AND a.pause = 0
   AND b.pause = 0';
  END IF;
  @strresult := sql1;
END;

}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_160_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_COMPANY_VILL_Y]'',q''[1]'',q''[]'',q''[AR_COMPANY_VILL_DESC_Y]'',q''[]'',q''[]'',q''[AR_COMPANY_VILL_Y]'',0,q''[]'',q''[AR_COMPANY_VILL_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_160_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_COMPANY_VILL_Y]'',q''[1]'',q''[]'',''look_a_supp_160_1'',q''[AR_COMPANY_VILL_DESC_Y]'',q''[]'',q''[]'',q''[AR_COMPANY_VILL_Y]'',0,q''[]'',q''[AR_COMPANY_VILL_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  sql1 VARCHAR2(3000);
BEGIN
  sql1 := 'SELECT a.villid ar_factory_vill_y, a.vill ar_factory_vill_desc_y FROM scmdata.dic_village a';
  IF :factory_county IS NOT NULL THEN
    sql1 := 'SELECT a.villid ar_factory_vill_y, a.vill ar_factory_vill_desc_y
  FROM scmdata.dic_village a
 INNER JOIN scmdata.dic_county b
    ON a.countyid = b.countyid
 WHERE a.countyid = :factory_county
   AND a.pause = 0
   AND b.pause = 0';
  END IF;
  @strresult := sql1;
END;
}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_FACTORY_VILL_Y]'',q''[1]'',q''[]'',q''[AR_FACTORY_VILL_DESC_Y]'',q''[]'',q''[]'',q''[AR_FACTORY_VILL_Y]'',0,q''[]'',q''[AR_FACTORY_VILL_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_FACTORY_VILL_Y]'',q''[1]'',q''[]'',''look_a_coop_151_1'',q''[AR_FACTORY_VILL_DESC_Y]'',q''[]'',q''[]'',q''[AR_FACTORY_VILL_Y]'',0,q''[]'',q''[AR_FACTORY_VILL_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'PAY_TERM',p_field_value => 'AR_PAY_TERM_N',p_field_desc => 'AR_PAY_TERM_DESC_N');
  @strresult := v_sql;
END;}

/*{DECLARE
  v_sql CLOB;
  v_ask_record_id varchar2(32) := :ask_record_id;
BEGIN
  IF :ar_cooperation_model_y IS NULL OR :ar_cooperation_model_y = 'OF' THEN
    v_sql := 'SELECT NULL AR_PAY_TERM_N, NULL AR_PAY_TERM_DESC_N FROM DUAL';
  ELSE
    v_sql := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'PAY_TERM',
                                                            p_field_value     => 'AR_PAY_TERM_N',
                                                            p_field_desc      => 'AR_PAY_TERM_DESC_N');
  END IF;
  @strresult := v_sql;
END;
}*/^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PAY_TERM_N]'',q''[1]'',q''[]'',q''[AR_PAY_TERM_DESC_N]'',q''[]'',q''[]'',q''[AR_PAY_TERM_N]'',0,q''[]'',q''[AR_PAY_TERM_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PAY_TERM_N]'',q''[1]'',q''[]'',''look_a_coop_151_2'',q''[AR_PAY_TERM_DESC_N]'',q''[]'',q''[]'',q''[AR_PAY_TERM_N]'',0,q''[]'',q''[AR_PAY_TERM_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'ROLE',
                                                               p_field_value     => 'AR_PERSON_ROLE_N',
                                                               p_field_desc      => 'AR_PERSON_ROLE_DESC_N',
                                                               p_company_id      => %default_company_id%,
                                                               p_is_company_dict => 1);
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_1_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PERSON_ROLE_N]'',q''[1]'',q''[]'',q''[AR_PERSON_ROLE_DESC_N]'',q''[]'',q''[]'',q''[AR_PERSON_ROLE_N]'',0,q''[]'',q''[AR_PERSON_ROLE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_1_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PERSON_ROLE_N]'',q''[1]'',q''[]'',''look_a_coop_151_1_1'',q''[AR_PERSON_ROLE_DESC_N]'',q''[]'',q''[]'',q''[AR_PERSON_ROLE_N]'',0,q''[]'',q''[AR_PERSON_ROLE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t.company_dict_value AR_DEPARTMENT_N, t.company_dict_name AR_DEPARTMENT_DESC_N
  FROM scmdata.sys_company_dict t
 WHERE (t.company_dict_type, t.company_id) IN
       (SELECT a.company_dict_value, a.company_id
          FROM scmdata.sys_company_dict a
         WHERE a.company_dict_type = 'ROLE'
           AND a.company_id = %default_company_id%)^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_1_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_DEPARTMENT_N]'',q''[1]'',q''[]'',q''[AR_DEPARTMENT_DESC_N]'',q''[]'',q''[]'',q''[AR_DEPARTMENT_N]'',0,q''[]'',q''[AR_DEPARTMENT_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_1_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_DEPARTMENT_N]'',q''[1]'',q''[]'',''look_a_coop_151_1_2'',q''[AR_DEPARTMENT_DESC_N]'',q''[]'',q''[]'',q''[AR_DEPARTMENT_N]'',0,q''[]'',q''[AR_DEPARTMENT_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t.company_dict_value AR_PERSON_JOB_N, t.company_dict_name AR_PERSON_JOB_DESC_N
  FROM scmdata.sys_company_dict t
 WHERE (t.company_dict_type, t.company_id) IN
       (SELECT b.company_dict_value, b.company_id
          FROM scmdata.sys_company_dict b
         WHERE (b.company_dict_type, b.company_id) IN
               (SELECT a.company_dict_value, a.company_id
                  FROM scmdata.sys_company_dict a
                 WHERE a.company_dict_type = 'ROLE'
                   AND a.company_id = 'a972dd1ffe3b3a10e0533c281cac8fd7'))^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_1_3''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PERSON_JOB_N]'',q''[1]'',q''[]'',q''[AR_PERSON_JOB_DESC_N]'',q''[]'',q''[]'',q''[AR_PERSON_JOB_N]'',0,q''[]'',q''[AR_PERSON_JOB_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_1_3''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PERSON_JOB_N]'',q''[1]'',q''[]'',''look_a_coop_151_1_3'',q''[AR_PERSON_JOB_DESC_N]'',q''[]'',q''[]'',q''[AR_PERSON_JOB_N]'',0,q''[]'',q''[AR_PERSON_JOB_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'EQUIPMENT_CATEGORY',
                                                               p_field_value     => 'AR_EQUIPMENT_CATE_N',
                                                               p_field_desc      => 'AR_EQUIP_CATE_DESC_N',
                                                               p_company_id      => %default_company_id%,
                                                               p_is_company_dict => 1);
  @strresult := v_sql;
END;
}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_2_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_EQUIPMENT_CATE_N]'',q''[1]'',q''[]'',q''[AR_EQUIP_CATE_DESC_N]'',q''[]'',q''[]'',q''[AR_EQUIPMENT_CATE_N]'',0,q''[]'',q''[AR_EQUIP_CATE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_2_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_EQUIPMENT_CATE_N]'',q''[1]'',q''[]'',''look_a_coop_151_2_1'',q''[AR_EQUIP_CATE_DESC_N]'',q''[]'',q''[]'',q''[AR_EQUIPMENT_CATE_N]'',0,q''[]'',q''[AR_EQUIP_CATE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'APPLY_CATEGORY',
                                                               p_field_value     => 'AR_APPLY_CATE_N',
                                                               p_field_desc      => 'AR_APPLY_CATE_DESC_N',
                                                               p_company_id      => %default_company_id%,
                                                               p_is_company_dict => 1);
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_1_4''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_APPLY_CATE_N]'',q''[1]'',q''[]'',q''[AR_APPLY_CATE_DESC_N]'',q''[]'',q''[]'',q''[AR_APPLY_CATE_N]'',0,q''[]'',q''[AR_APPLY_CATE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_1_4''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_APPLY_CATE_N]'',q''[1]'',q''[]'',''look_a_coop_151_1_4'',q''[AR_APPLY_CATE_DESC_N]'',q''[]'',q''[]'',q''[AR_APPLY_CATE_N]'',0,q''[]'',q''[AR_APPLY_CATE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'PRODUCT_LINE',p_field_value => 'AR_PRODUCT_LINE_N',p_field_desc => 'AR_PRODUCT_LINE_DESC_N');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_5''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PRODUCT_LINE_N]'',q''[1]'',q''[]'',q''[AR_PRODUCT_LINE_DESC_N]'',q''[]'',q''[]'',q''[AR_PRODUCT_LINE_N]'',0,q''[]'',q''[AR_PRODUCT_LINE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_5''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PRODUCT_LINE_N]'',q''[1]'',q''[]'',''look_a_coop_151_5'',q''[AR_PRODUCT_LINE_DESC_N]'',q''[]'',q''[]'',q''[AR_PRODUCT_LINE_N]'',0,q''[]'',q''[AR_PRODUCT_LINE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
   sql1 VARCHAR2(3000);
BEGIN
   sql1:='SELECT a.villid  FACTORY_VILL,a.VILL FACTORY_VILL_DESC FROM scmdata.DIC_VILLAGE a';
   IF :FACTORY_COUNTY is not null  THEN
    sql1 := 'SELECT a.villid  FACTORY_VILL,a.VILL FACTORY_VILL_DESC
               FROM scmdata.DIC_VILLAGE a
              inner join scmdata.DIC_county b on a.countyid=b.countyid
              where a.countyid=:FACTORY_COUNTY and a.pause=0 and b.pause=0';
  END IF;
  @strResult := sql1;
END;
}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_160_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[FACTORY_VILL]'',q''[1]'',q''[]'',q''[FACTORY_VILL_DESC]'',q''[]'',q''[]'',q''[FACTORY_VILL]'',0,q''[]'',q''[FACTORY_VILL_DESC]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_160_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[FACTORY_VILL]'',q''[1]'',q''[]'',''look_a_supp_160_2'',q''[FACTORY_VILL_DESC]'',q''[]'',q''[]'',q''[FACTORY_VILL]'',0,q''[]'',q''[FACTORY_VILL_DESC]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
   sql1 VARCHAR2(3000);
BEGIN
   sql1:='SELECT a.villid  FACTORY_VILL,a.VILL FACTORY_VILL_DESC FROM scmdata.DIC_VILLAGE a';
   IF :FACTORY_COUNTY is not null  THEN
    sql1 := 'SELECT a.villid  FACTORY_VILL,a.VILL FACTORY_VILL_DESC
               FROM scmdata.DIC_VILLAGE a
              inner join scmdata.DIC_county b on a.countyid=b.countyid
              where a.countyid=:FACTORY_COUNTY and a.pause=0 and b.pause=0';
  END IF;
  @strResult := sql1;
END;
}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_160_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[FACTORY_VILL]'',q''[1]'',q''[]'',q''[FACTORY_VILL_DESC]'',q''[]'',q''[]'',q''[FACTORY_VILL]'',0,q''[]'',q''[FACTORY_VILL_DESC]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_160_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[FACTORY_VILL]'',q''[1]'',q''[]'',''look_a_supp_160_2'',q''[FACTORY_VILL_DESC]'',q''[]'',q''[]'',q''[FACTORY_VILL]'',0,q''[]'',q''[FACTORY_VILL_DESC]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^--czh 重构代码
{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'IS_URGENT',p_field_value     => 'FA_IS_URGENT_N',p_field_desc      => 'FA_IS_URGENT_DESC_N');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_150_3_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[FA_IS_URGENT_N]'',q''[1]'',q''[0]'',q''[FA_IS_URGENT_DESC_N]'',q''[]'',q''[]'',q''[FA_IS_URGENT_N]'',0,q''[]'',q''[FA_IS_URGENT_DESC_N]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_150_3_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[FA_IS_URGENT_N]'',q''[1]'',q''[0]'',''look_a_coop_150_3_1'',q''[FA_IS_URGENT_DESC_N]'',q''[]'',q''[]'',q''[FA_IS_URGENT_N]'',0,q''[]'',q''[FA_IS_URGENT_DESC_N]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^--czh 重构代码
{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := pkg_ask_record_mange.f_query_lookup_product_type(p_product_type_field => 'PRODUCT_TYPE',p_suffix => '_DESC');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_150_3_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[PRODUCT_TYPE]'',q''[1]'',q''[0]'',q''[PRODUCT_TYPE_DESC]'',q''[]'',q''[]'',q''[PRODUCT_TYPE]'',0,q''[]'',q''[PRODUCT_TYPE_DESC]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_150_3_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[PRODUCT_TYPE]'',q''[1]'',q''[0]'',''look_a_coop_150_3_2'',q''[PRODUCT_TYPE_DESC]'',q''[]'',q''[]'',q''[PRODUCT_TYPE]'',0,q''[]'',q''[PRODUCT_TYPE_DESC]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^--czh 重构代码
{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'FACTORY_TYPE',
                                                               p_field_value     => 'FACTORY_TYPE',
                                                               p_field_desc      => 'FACTORY_TYPE_DESC');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_150_3_4''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[FACTORY_TYPE]'',q''[1]'',q''[0]'',q''[FACTORY_TYPE_DESC]'',q''[]'',q''[]'',q''[FACTORY_TYPE]'',0,q''[]'',q''[FACTORY_TYPE_DESC]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_150_3_4''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[FACTORY_TYPE]'',q''[1]'',q''[0]'',''look_a_coop_150_3_4'',q''[FACTORY_TYPE_DESC]'',q''[]'',q''[]'',q''[FACTORY_TYPE]'',0,q''[]'',q''[FACTORY_TYPE_DESC]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'COMPANY_TYPE',p_field_value => 'AR_COMPANY_TYPE_Y',p_field_desc => 'AR_COMPANY_TYPE_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_121_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_COMPANY_TYPE_Y]'',q''[1]'',q''[0]'',q''[AR_COMPANY_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_COMPANY_TYPE_Y]'',0,q''[]'',q''[AR_COMPANY_TYPE_DESC_Y]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_121_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_COMPANY_TYPE_Y]'',q''[1]'',q''[0]'',''look_a_coop_121_2'',q''[AR_COMPANY_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_COMPANY_TYPE_Y]'',0,q''[]'',q''[AR_COMPANY_TYPE_DESC_Y]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'COMPANY_TYPE',p_field_value => 'AR_COMPANY_TYPE_Y',p_field_desc => 'AR_COMPANY_TYPE_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_121_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_COMPANY_TYPE_Y]'',q''[1]'',q''[0]'',q''[AR_COMPANY_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_COMPANY_TYPE_Y]'',0,q''[]'',q''[AR_COMPANY_TYPE_DESC_Y]'',0,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_121_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_COMPANY_TYPE_Y]'',q''[1]'',q''[0]'',''look_a_coop_121_2'',q''[AR_COMPANY_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_COMPANY_TYPE_Y]'',0,q''[]'',q''[AR_COMPANY_TYPE_DESC_Y]'',0,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'EQUIPMENT_CATEGORY',
                                                               p_field_value     => 'AR_EQUIPMENT_CATE_N',
                                                               p_field_desc      => 'AR_EQUIP_CATE_DESC_N',
                                                               p_company_id      => %default_company_id%,
                                                               p_is_company_dict => 1);
  @strresult := v_sql;
END;
}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_2_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_EQUIPMENT_CATE_N]'',q''[1]'',q''[]'',q''[AR_EQUIP_CATE_DESC_N]'',q''[]'',q''[]'',q''[AR_EQUIPMENT_CATE_N]'',0,q''[]'',q''[AR_EQUIP_CATE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_2_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_EQUIPMENT_CATE_N]'',q''[1]'',q''[]'',''look_a_coop_151_2_1'',q''[AR_EQUIP_CATE_DESC_N]'',q''[]'',q''[]'',q''[AR_EQUIPMENT_CATE_N]'',0,q''[]'',q''[AR_EQUIP_CATE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t.company_dict_value AR_DEPARTMENT_N, t.company_dict_name AR_DEPARTMENT_DESC_N
  FROM scmdata.sys_company_dict t
 WHERE (t.company_dict_type, t.company_id) IN
       (SELECT a.company_dict_value, a.company_id
          FROM scmdata.sys_company_dict a
         WHERE a.company_dict_type = 'ROLE'
           AND a.company_id = %default_company_id%)^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_1_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_DEPARTMENT_N]'',q''[1]'',q''[]'',q''[AR_DEPARTMENT_DESC_N]'',q''[]'',q''[]'',q''[AR_DEPARTMENT_N]'',0,q''[]'',q''[AR_DEPARTMENT_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_1_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_DEPARTMENT_N]'',q''[1]'',q''[]'',''look_a_coop_151_1_2'',q''[AR_DEPARTMENT_DESC_N]'',q''[]'',q''[]'',q''[AR_DEPARTMENT_N]'',0,q''[]'',q''[AR_DEPARTMENT_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t.company_dict_value AR_PERSON_JOB_N, t.company_dict_name AR_PERSON_JOB_DESC_N
  FROM scmdata.sys_company_dict t
 WHERE (t.company_dict_type, t.company_id) IN
       (SELECT b.company_dict_value, b.company_id
          FROM scmdata.sys_company_dict b
         WHERE (b.company_dict_type, b.company_id) IN
               (SELECT a.company_dict_value, a.company_id
                  FROM scmdata.sys_company_dict a
                 WHERE a.company_dict_type = 'ROLE'
                   AND a.company_id = 'a972dd1ffe3b3a10e0533c281cac8fd7'))^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_1_3''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PERSON_JOB_N]'',q''[1]'',q''[]'',q''[AR_PERSON_JOB_DESC_N]'',q''[]'',q''[]'',q''[AR_PERSON_JOB_N]'',0,q''[]'',q''[AR_PERSON_JOB_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_1_3''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PERSON_JOB_N]'',q''[1]'',q''[]'',''look_a_coop_151_1_3'',q''[AR_PERSON_JOB_DESC_N]'',q''[]'',q''[]'',q''[AR_PERSON_JOB_N]'',0,q''[]'',q''[AR_PERSON_JOB_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'APPLY_CATEGORY',
                                                               p_field_value     => 'AR_APPLY_CATE_N',
                                                               p_field_desc      => 'AR_APPLY_CATE_DESC_N',
                                                               p_company_id      => %default_company_id%,
                                                               p_is_company_dict => 1);
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_1_4''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_APPLY_CATE_N]'',q''[1]'',q''[]'',q''[AR_APPLY_CATE_DESC_N]'',q''[]'',q''[]'',q''[AR_APPLY_CATE_N]'',0,q''[]'',q''[AR_APPLY_CATE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_1_4''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_APPLY_CATE_N]'',q''[1]'',q''[]'',''look_a_coop_151_1_4'',q''[AR_APPLY_CATE_DESC_N]'',q''[]'',q''[]'',q''[AR_APPLY_CATE_N]'',0,q''[]'',q''[AR_APPLY_CATE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'PAY_TERM',p_field_value => 'AR_PAY_TERM_N',p_field_desc => 'AR_PAY_TERM_DESC_N');
  @strresult := v_sql;
END;}

/*{DECLARE
  v_sql CLOB;
  v_ask_record_id varchar2(32) := :ask_record_id;
BEGIN
  IF :ar_cooperation_model_y IS NULL OR :ar_cooperation_model_y = 'OF' THEN
    v_sql := 'SELECT NULL AR_PAY_TERM_N, NULL AR_PAY_TERM_DESC_N FROM DUAL';
  ELSE
    v_sql := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'PAY_TERM',
                                                            p_field_value     => 'AR_PAY_TERM_N',
                                                            p_field_desc      => 'AR_PAY_TERM_DESC_N');
  END IF;
  @strresult := v_sql;
END;
}*/^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PAY_TERM_N]'',q''[1]'',q''[]'',q''[AR_PAY_TERM_DESC_N]'',q''[]'',q''[]'',q''[AR_PAY_TERM_N]'',0,q''[]'',q''[AR_PAY_TERM_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PAY_TERM_N]'',q''[1]'',q''[]'',''look_a_coop_151_2'',q''[AR_PAY_TERM_DESC_N]'',q''[]'',q''[]'',q''[AR_PAY_TERM_N]'',0,q''[]'',q''[AR_PAY_TERM_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'PAY_TERM',p_field_value => 'AR_PAY_TERM_N',p_field_desc => 'AR_PAY_TERM_DESC_N');
  @strresult := v_sql;
END;}

/*{DECLARE
  v_sql CLOB;
  v_ask_record_id varchar2(32) := :ask_record_id;
BEGIN
  IF :ar_cooperation_model_y IS NULL OR :ar_cooperation_model_y = 'OF' THEN
    v_sql := 'SELECT NULL AR_PAY_TERM_N, NULL AR_PAY_TERM_DESC_N FROM DUAL';
  ELSE
    v_sql := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'PAY_TERM',
                                                            p_field_value     => 'AR_PAY_TERM_N',
                                                            p_field_desc      => 'AR_PAY_TERM_DESC_N');
  END IF;
  @strresult := v_sql;
END;
}*/^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_2''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PAY_TERM_N]'',q''[1]'',q''[]'',q''[AR_PAY_TERM_DESC_N]'',q''[]'',q''[]'',q''[AR_PAY_TERM_N]'',0,q''[]'',q''[AR_PAY_TERM_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_2''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PAY_TERM_N]'',q''[1]'',q''[]'',''look_a_coop_151_2'',q''[AR_PAY_TERM_DESC_N]'',q''[]'',q''[]'',q''[AR_PAY_TERM_N]'',0,q''[]'',q''[AR_PAY_TERM_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'FABRIC_PURCHASE_CAP',p_field_value => 'AR_FABRIC_PURCHASE_CAP_Y',p_field_desc => 'AR_FABRIC_PUR_CAP_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_8''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_FABRIC_PURCHASE_CAP_Y]'',q''[1]'',q''[]'',q''[AR_FABRIC_PUR_CAP_DESC_Y]'',q''[]'',q''[]'',q''[AR_FABRIC_PURCHASE_CAP_Y]'',0,q''[]'',q''[AR_FABRIC_PUR_CAP_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_8''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_FABRIC_PURCHASE_CAP_Y]'',q''[1]'',q''[]'',''look_a_coop_151_8'',q''[AR_FABRIC_PUR_CAP_DESC_Y]'',q''[]'',q''[]'',q''[AR_FABRIC_PURCHASE_CAP_Y]'',0,q''[]'',q''[AR_FABRIC_PUR_CAP_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'IS_OUR_FACTORY',p_field_value => 'AR_IS_OUR_FACTORY_Y',p_field_desc => 'AR_IS_OUR_FAC_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_4''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_IS_OUR_FACTORY_Y]'',q''[1]'',q''[]'',q''[AR_IS_OUR_FAC_DESC_Y]'',q''[]'',q''[]'',q''[AR_IS_OUR_FACTORY_Y]'',0,q''[]'',q''[AR_IS_OUR_FAC_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_4''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_IS_OUR_FACTORY_Y]'',q''[1]'',q''[]'',''look_a_coop_151_4'',q''[AR_IS_OUR_FAC_DESC_Y]'',q''[]'',q''[]'',q''[AR_IS_OUR_FACTORY_Y]'',0,q''[]'',q''[AR_IS_OUR_FAC_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t.group_name group_name_desc, t.group_config_id group_name
  FROM scmdata.t_supplier_group_config t
 WHERE t.company_id = %default_company_id%^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_151''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[GROUP_NAME]'',q''[1]'',q''[]'',q''[GROUP_NAME_DESC]'',q''[]'',q''[]'',q''[GROUP_NAME]'',,q''[]'',q''[GROUP_NAME_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_151''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[GROUP_NAME]'',q''[1]'',q''[]'',''look_a_supp_151'',q''[GROUP_NAME_DESC]'',q''[]'',q''[]'',q''[GROUP_NAME]'',,q''[]'',q''[GROUP_NAME_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'COOP_POSITION',
                                                               p_field_value     => 'SP_COOP_POSITION_N',
                                                               p_field_desc      => 'SP_COOP_POSITION_DESC_N');
  @strresult := v_sql;
END;
}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_111_18''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[SP_COOP_POSITION_N]'',q''[1]'',q''[]'',q''[SP_COOP_POSITION_DESC_N]'',q''[]'',q''[]'',q''[SP_COOP_POSITION_N]'',0,q''[]'',q''[SP_COOP_POSITION_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_111_18''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[SP_COOP_POSITION_N]'',q''[1]'',q''[]'',''look_a_supp_111_18'',q''[SP_COOP_POSITION_DESC_N]'',q''[]'',q''[]'',q''[SP_COOP_POSITION_N]'',0,q''[]'',q''[SP_COOP_POSITION_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'IS_OUR_FACTORY',p_field_value => 'AR_IS_OUR_FACTORY_Y',p_field_desc => 'AR_IS_OUR_FAC_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_4''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_IS_OUR_FACTORY_Y]'',q''[1]'',q''[]'',q''[AR_IS_OUR_FAC_DESC_Y]'',q''[]'',q''[]'',q''[AR_IS_OUR_FACTORY_Y]'',0,q''[]'',q''[AR_IS_OUR_FAC_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_4''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_IS_OUR_FACTORY_Y]'',q''[1]'',q''[]'',''look_a_coop_151_4'',q''[AR_IS_OUR_FAC_DESC_Y]'',q''[]'',q''[]'',q''[AR_IS_OUR_FACTORY_Y]'',0,q''[]'',q''[AR_IS_OUR_FAC_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'FABRIC_CHECK_CAP',p_field_value => 'AR_FABRIC_CHECK_CAP_N',p_field_desc => 'AR_FABRIC_CHECK_CAP_DESC_N');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_9''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_FABRIC_CHECK_CAP_N]'',q''[1]'',q''[]'',q''[AR_FABRIC_CHECK_CAP_DESC_N]'',q''[]'',q''[]'',q''[AR_FABRIC_CHECK_CAP_N]'',0,q''[]'',q''[AR_FABRIC_CHECK_CAP_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_9''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_FABRIC_CHECK_CAP_N]'',q''[1]'',q''[]'',''look_a_coop_151_9'',q''[AR_FABRIC_CHECK_CAP_DESC_N]'',q''[]'',q''[]'',q''[AR_FABRIC_CHECK_CAP_N]'',0,q''[]'',q''[AR_FABRIC_CHECK_CAP_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql       CLOB;
  v_where_sql VARCHAR2(256);
BEGIN

  v_sql := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'FA_PRODUCT_TYPE',
                                                          p_field_value     => 'AR_PRODUCT_TYPE_Y',
                                                          p_field_desc      => 'AR_PRODUCT_TYPE_DESC_Y');

  IF :ar_cooperation_model_y IN ('ODM', 'OEM') THEN
    v_where_sql := Q'[ WHERE AR_PRODUCT_TYPE_Y = '00']';
    v_sql       := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'FA_PRODUCT_TYPE',
                                                                  p_field_value     => 'AR_PRODUCT_TYPE_Y',
                                                                  p_field_desc      => 'AR_PRODUCT_TYPE_DESC_Y',
                                                                  p_where_sql       => v_where_sql);
  END IF;
  @strresult := v_sql;
END;
}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_3''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PRODUCT_TYPE_Y]'',q''[1]'',q''[]'',q''[AR_PRODUCT_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_PRODUCT_TYPE_Y]'',0,q''[]'',q''[AR_PRODUCT_TYPE_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_3''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PRODUCT_TYPE_Y]'',q''[1]'',q''[]'',''look_a_coop_151_3'',q''[AR_PRODUCT_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_PRODUCT_TYPE_Y]'',0,q''[]'',q''[AR_PRODUCT_TYPE_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'PATTERN_CAP',p_field_value => 'AR_PATTERN_CAP_Y',p_field_desc => 'AR_PATTERN_CAP_DESC_Y');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_7''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PATTERN_CAP_Y]'',q''[1]'',q''[]'',q''[AR_PATTERN_CAP_DESC_Y]'',q''[]'',q''[]'',q''[AR_PATTERN_CAP_Y]'',0,q''[]'',q''[AR_PATTERN_CAP_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_7''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PATTERN_CAP_Y]'',q''[1]'',q''[]'',''look_a_coop_151_7'',q''[AR_PATTERN_CAP_DESC_Y]'',q''[]'',q''[]'',q''[AR_PATTERN_CAP_Y]'',0,q''[]'',q''[AR_PATTERN_CAP_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  sql1 VARCHAR2(3000);
BEGIN
  sql1 := 'SELECT a.villid ar_company_vill_y, a.vill ar_company_vill_desc_y FROM scmdata.dic_village a';
  IF :company_county IS NOT NULL THEN
    sql1 := 'SELECT a.villid ar_company_vill_y, a.vill ar_company_vill_desc_y
  FROM scmdata.dic_village a
 INNER JOIN scmdata.dic_county b
    ON a.countyid = b.countyid
 WHERE a.countyid = :company_county
   AND a.pause = 0
   AND b.pause = 0';
  END IF;
  @strresult := sql1;
END;

}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_160_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_COMPANY_VILL_Y]'',q''[1]'',q''[]'',q''[AR_COMPANY_VILL_DESC_Y]'',q''[]'',q''[]'',q''[AR_COMPANY_VILL_Y]'',0,q''[]'',q''[AR_COMPANY_VILL_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_160_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_COMPANY_VILL_Y]'',q''[1]'',q''[]'',''look_a_supp_160_1'',q''[AR_COMPANY_VILL_DESC_Y]'',q''[]'',q''[]'',q''[AR_COMPANY_VILL_Y]'',0,q''[]'',q''[AR_COMPANY_VILL_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'PRODUCT_LINE',p_field_value => 'AR_PRODUCT_LINE_N',p_field_desc => 'AR_PRODUCT_LINE_DESC_N');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_5''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PRODUCT_LINE_N]'',q''[1]'',q''[]'',q''[AR_PRODUCT_LINE_DESC_N]'',q''[]'',q''[]'',q''[AR_PRODUCT_LINE_N]'',0,q''[]'',q''[AR_PRODUCT_LINE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_5''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PRODUCT_LINE_N]'',q''[1]'',q''[]'',''look_a_coop_151_5'',q''[AR_PRODUCT_LINE_DESC_N]'',q''[]'',q''[]'',q''[AR_PRODUCT_LINE_N]'',0,q''[]'',q''[AR_PRODUCT_LINE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'FABRIC_CHECK_CAP',p_field_value => 'AR_FABRIC_CHECK_CAP_N',p_field_desc => 'AR_FABRIC_CHECK_CAP_DESC_N');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_9''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_FABRIC_CHECK_CAP_N]'',q''[1]'',q''[]'',q''[AR_FABRIC_CHECK_CAP_DESC_N]'',q''[]'',q''[]'',q''[AR_FABRIC_CHECK_CAP_N]'',0,q''[]'',q''[AR_FABRIC_CHECK_CAP_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_9''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_FABRIC_CHECK_CAP_N]'',q''[1]'',q''[]'',''look_a_coop_151_9'',q''[AR_FABRIC_CHECK_CAP_DESC_N]'',q''[]'',q''[]'',q''[AR_FABRIC_CHECK_CAP_N]'',0,q''[]'',q''[AR_FABRIC_CHECK_CAP_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{
DECLARE
  v_sql       CLOB;
  v_where_sql VARCHAR2(256);
BEGIN

  v_sql := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'FA_PRODUCT_TYPE',
                                                          p_field_value     => 'AR_PRODUCT_TYPE_Y',
                                                          p_field_desc      => 'AR_PRODUCT_TYPE_DESC_Y');

  IF :ar_cooperation_model_y IN ('ODM', 'OEM') THEN
    v_where_sql := Q'[ WHERE AR_PRODUCT_TYPE_Y = '00']';
    v_sql       := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'FA_PRODUCT_TYPE',
                                                                  p_field_value     => 'AR_PRODUCT_TYPE_Y',
                                                                  p_field_desc      => 'AR_PRODUCT_TYPE_DESC_Y',
                                                                  p_where_sql       => v_where_sql);
  END IF;
  @strresult := v_sql;
END;
}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_3''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PRODUCT_TYPE_Y]'',q''[1]'',q''[]'',q''[AR_PRODUCT_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_PRODUCT_TYPE_Y]'',0,q''[]'',q''[AR_PRODUCT_TYPE_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_3''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PRODUCT_TYPE_Y]'',q''[1]'',q''[]'',''look_a_coop_151_3'',q''[AR_PRODUCT_TYPE_DESC_Y]'',q''[]'',q''[]'',q''[AR_PRODUCT_TYPE_Y]'',0,q''[]'',q''[AR_PRODUCT_TYPE_DESC_Y]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'QUALITY_STEP',p_field_value => 'AR_QUALITY_STEP_N',p_field_desc => 'AR_QUALITY_STEP_DESC_N');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_6''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_QUALITY_STEP_N]'',q''[1]'',q''[]'',q''[AR_QUALITY_STEP_DESC_N]'',q''[]'',q''[]'',q''[AR_QUALITY_STEP_N]'',0,q''[]'',q''[AR_QUALITY_STEP_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_6''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_QUALITY_STEP_N]'',q''[1]'',q''[]'',''look_a_coop_151_6'',q''[AR_QUALITY_STEP_DESC_N]'',q''[]'',q''[]'',q''[AR_QUALITY_STEP_N]'',0,q''[]'',q''[AR_QUALITY_STEP_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type (p_group_dict_type => 'QUALITY_STEP',p_field_value => 'AR_QUALITY_STEP_N',p_field_desc => 'AR_QUALITY_STEP_DESC_N');
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_6''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_QUALITY_STEP_N]'',q''[1]'',q''[]'',q''[AR_QUALITY_STEP_DESC_N]'',q''[]'',q''[]'',q''[AR_QUALITY_STEP_N]'',0,q''[]'',q''[AR_QUALITY_STEP_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_6''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_QUALITY_STEP_N]'',q''[1]'',q''[]'',''look_a_coop_151_6'',q''[AR_QUALITY_STEP_DESC_N]'',q''[]'',q''[]'',q''[AR_QUALITY_STEP_N]'',0,q''[]'',q''[AR_QUALITY_STEP_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^SELECT t.group_name group_name_desc, t.group_config_id group_name
  FROM scmdata.t_supplier_group_config t
 WHERE t.company_id = %default_company_id%
   AND t.pause = 1^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_supp_161''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[GROUP_NAME]'',q''[1]'',q''[]'',q''[GROUP_NAME_DESC]'',q''[]'',q''[]'',q''[GROUP_NAME]'',,q''[]'',q''[GROUP_NAME_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_supp_161''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[GROUP_NAME]'',q''[1]'',q''[]'',''look_a_supp_161'',q''[GROUP_NAME_DESC]'',q''[]'',q''[]'',q''[GROUP_NAME]'',,q''[]'',q''[GROUP_NAME_DESC]'',,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

BEGIN
  DECLARE
    JUDGE_N NUMBER(4);
    EXE_SQL CLOB;
    VALS    CLOB;
  CV1 CLOB:=q'^{DECLARE
  v_sql CLOB;
BEGIN
  v_sql      := scmdata.pkg_plat_comm.f_get_lookup_sql_by_type(p_group_dict_type => 'ROLE',
                                                               p_field_value     => 'AR_PERSON_ROLE_N',
                                                               p_field_desc      => 'AR_PERSON_ROLE_DESC_N',
                                                               p_company_id      => %default_company_id%,
                                                               p_is_company_dict => 1);
  @strresult := v_sql;
END;}^';
  CV2 CLOB:=q'^^';

  BEGIN
    EXE_SQL := 'SELECT COUNT(1) FROM BW3.SYS_LOOK_UP WHERE ELEMENT_ID = ''look_a_coop_151_1_1''';
    EXECUTE IMMEDIATE EXE_SQL INTO JUDGE_N;
    IF JUDGE_N > 0 THEN
       EXE_SQL := 'UPDATE BW3.SYS_LOOK_UP SET (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) = (SELECT q''[AR_PERSON_ROLE_N]'',q''[1]'',q''[]'',q''[AR_PERSON_ROLE_DESC_N]'',q''[]'',q''[]'',q''[AR_PERSON_ROLE_N]'',0,q''[]'',q''[AR_PERSON_ROLE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL) WHERE ELEMENT_ID = ''look_a_coop_151_1_1''';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     ELSE
       EXE_SQL := 'INSERT INTO BW3.SYS_LOOK_UP (BEFORE_FIELD,DATA_TYPE,DISABLED_FIELD,ELEMENT_ID,FIELD_NAME,GROUP_FIELD,ICON,KEY_FIELD,MULTI_VALUE_FLAG,PORT_ID,RESULT_FIELD,SEARCH_FLAG,VALUE_SEP,LOOK_UP_SQL,PORT_SQL) SELECT q''[AR_PERSON_ROLE_N]'',q''[1]'',q''[]'',''look_a_coop_151_1_1'',q''[AR_PERSON_ROLE_DESC_N]'',q''[]'',q''[]'',q''[AR_PERSON_ROLE_N]'',0,q''[]'',q''[AR_PERSON_ROLE_DESC_N]'',1,q''[]'',:CV1,:CV2 FROM DUAL';
       WHILE REGEXP_COUNT(EXE_SQL,',,') > 0 LOOP
         EXE_SQL := REPLACE(EXE_SQL,',,',',NULL,');
       END LOOP;
       EXE_SQL := REPLACE(REPLACE(EXE_SQL,'SELECT ,','SELECT NULL,'),', FROM',',NULL FROM');
       EXECUTE IMMEDIATE EXE_SQL USING CV1,CV2;
     END IF;
  END;
END;
/

