INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_SUP_COMPANY_NAME_Y', '��Ӧ������', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_SUP_COMPANY_ABB_Y', '��Ӧ�̼��', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_SOCIAL_CREDIT_CODE_Y', 'ͳһ�������֤������', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_SUPPLIER_CODE_N', '�������', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_INSIDE_SUPPLIER_CODE_N', '��Ӧ�̱��', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_COMPANY_REGIST_DATE_Y', '��˾ע������', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_LOCATION_AREA_Y', '��˾��������', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_COMPANY_VILL_Y', '��˾���ڽֵ�', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_COMPANY_ADDRESS_Y', '��˾��ϸ��ַ', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_GROUP_NAME_N', '��������', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_LEGAL_REPRESENT_N', '����������', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_COMPANY_CREATE_DATE_N', '��������', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_REGIST_ADDRESS_N', 'ע���ַ', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_CERTIFICATE_VALIDITY_START_N', 'Ӫҵִ�տ�ʼ��Ч��', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_CERTIFICATE_VALIDITY_END_N', 'Ӫҵִ�ս�ֹ��Ч��', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_REGIST_PRICE_N', 'ע���ʱ�', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_COMPANY_CONTACT_PHONE_N', '��˾��ϵ�绰', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_CONTACT_NAME_Y', 'ҵ����ϵ��', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_CONTACT_PHONE_Y', 'ҵ����ϵ�˵绰',1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_COMPANY_TYPE_Y', '��˾����', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_IS_OUR_FACTORY_Y', '�Ƿ񱾳�', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_FACTROY_AREA_Y', '�������(m2)', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_REMARKS_N', '��ע', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_PRODUCT_TYPE_Y', '��������', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_COOP_BRAND_DESC_N', '����Ʒ��/�ͻ�', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_PRODUCT_LINK_N', '��������', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_PRODUCT_LINE_N', '����������', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_PRODUCT_LINE_NUM_N', '����������(��)', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_QUALITY_STEP_Y', '�����ȼ�', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_WORK_HOURS_DAY_Y', '�ϰ�ʱ��/��', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_WORKER_TOTAL_NUM_Y', '������', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_WORKER_NUM_Y', '��λ����', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_MACHINE_NUM_Y', '֯��̨��_ë֯��', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_FORM_NUM_Y', '��������_Ь��', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_PRODUCT_EFFICIENCY_Y', '����Ч��(%)', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_PATTERN_CAP_Y', '�������', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_FABRIC_PURCHASE_CAP_Y', '���ϲɹ�����', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_FABRIC_CHECK_CAP_Y', '���ϼ������', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_COOP_STATUS_Y', '����״̬', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_REGIST_STATUS_N', 'ƽ̨ע��״̬', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_BIND_STATUS_N', 'Ӧ�ð�״̬', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_COOPERATION_TYPE_Y', '��������', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_COOPERATION_MODEL_Y', '����ģʽ', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_COOP_POSITION_N', '������λ', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_PAY_TERM_N', '��������', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_CERTIFICATE_FILE_Y', '��ҵ֤��', 1, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_SUPPLIER_GATE_N', '��˾����', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_SUPPLIER_OFFICE_N', '��˾�칫��', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_SUPPLIER_SITE_N', '�����ֳ�', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_SUPPLIER_PRODUCT_N', '��ƷͼƬ', 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO nbw.sys_field_list (field_name,caption,requiered_flag,read_only_flag,no_edit,no_copy,no_sort,alignment,ime_care,ime_open)
VALUES('SP_OTHER_INFORMATION_N', '��������', 0, 0, 0, 0, 0, 0, 0, 0);

