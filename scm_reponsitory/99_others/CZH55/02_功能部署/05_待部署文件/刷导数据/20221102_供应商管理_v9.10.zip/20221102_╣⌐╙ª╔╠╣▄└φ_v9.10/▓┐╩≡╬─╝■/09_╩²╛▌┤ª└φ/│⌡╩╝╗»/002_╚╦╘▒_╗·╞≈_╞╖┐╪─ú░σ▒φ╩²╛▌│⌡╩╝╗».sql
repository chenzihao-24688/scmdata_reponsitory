---��Ա����ģ�����ʼ��
insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70e66cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_00', 'ROLE_00_00', 'ROLE_00_00_00', 'APPLY_00', null, 1, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70e76cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_00', 'ROLE_00_01', 'ROLE_00_01_00', 'APPLY_00', '�����ư�ʦ������ʦ�����ʦ��ֽ��ʦ�����ʦ������ʦ������ͼʦ����', 2, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70e86cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_00', 'ROLE_00_01', 'ROLE_00_01_01', 'APPLY_00', null, 3, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70e96cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_00', 'ROLE_01_00_00', 'APPLY_00', '�����������ü������ϡ���Ƥ����Ƭ��', 4, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70ea6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_01', 'ROLE_01_01_00', 'APPLY_00', '�����鳤��ָ����������ʦ��������', 5, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70eb6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_01', 'ROLE_01_01_01', 'APPLY_00', '�������칤�����̡��복��', 6, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70ec6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_01', 'ROLE_01_01_02', 'APPLY_01', null, 7, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70ed6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_01', 'ROLE_01_01_03', 'APPLY_02', null, 8, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70ee6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_01', 'ROLE_01_01_04', 'APPLY_02', null, 9, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70ef6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_01', 'ROLE_01_01_05', 'APPLY_02', null, 10, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70f06cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_01', 'ROLE_01_01_06', 'APPLY_03', null, 11, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70f16cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_01', 'ROLE_01_01_07', 'APPLY_03', null, 12, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70f26cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_01', 'ROLE_01_01_08', 'APPLY_03', null, 13, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70f36cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_01', 'ROLE_01_01_09', 'APPLY_00', null, 14, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70f46cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_01', 'ROLE_01_01_10', 'APPLY_00', null, 15, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70f56cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_01', 'ROLE_01_01_11', 'APPLY_00', null, 16, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70f66cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_02', 'ROLE_01_02_00', 'APPLY_00', '����β�顢�ȳߡ��յơ����¡������', 17, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70f76cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_02', 'ROLE_01_02_01', 'APPLY_00', null, 18, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70f86cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_02', 'ROLE_01_02_02', 'APPLY_00', null, 19, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70f96cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_01', 'ROLE_01_02', 'ROLE_01_02_03', 'APPLY_00', '�������ߡ�ר�����ӹ���ϴ�桢����', 20, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70fa6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_02', 'ROLE_02_00', 'ROLE_02_00_00', 'APPLY_00', '�����鲼����⡢QC��QA��Ѳ���', 21, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70fb6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_03', 'ROLE_03_00', 'ROLE_03_00_00', 'APPLY_00', null, 22, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70fc6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_03', 'ROLE_03_01', 'ROLE_03_01_00', 'APPLY_00', null, 23, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70fd6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_04', 'ROLE_04_00', 'ROLE_04_00_00', 'APPLY_00', null, 24, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70fe6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_04', 'ROLE_04_00', 'ROLE_04_00_01', 'APPLY_00', '���������ž���/���ܵ�', 25, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_person_config (PERSON_CONFIG_ID, COMPANY_ID, PERSON_ROLE_ID, DEPARTMENT_ID, PERSON_JOB_ID, APPLY_CATEGORY_ID, JOB_STATE, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd70ff6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'ROLE_04', 'ROLE_04_01', 'ROLE_04_01_00', 'APPLY_00', '�������¡����ڡ����������񡢻��޵�', 26, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:34', 'dd-mm-yyyy hh24:mi:ss'));

---�����豸ģ�����ʼ��
insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71006cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_00', '������ܻ�', 1, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:42', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71016cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_00', '�鲼��', 2, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71026cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_00', 'Ԥ����', 3, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71036cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_01', '��ͨ�ô�', 4, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71046cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_01', '���Բô�', 5, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71056cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_02', '���ӻ�', 6, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71066cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_02', 'ѹ�̻�', 7, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71076cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_03', 'ƽ��', 8, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71086cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_03', '˫�복', 9, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71096cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_03', '�ݳ�', 10, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd710a6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_03', '���߿��߳�', 11, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd710b6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_03', '���߿��߳�', 12, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd710c6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_03', '���߿��߳�', 13, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd710d6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_04', '��г�', 14, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd710e6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_04', 'ꤽų�', 15, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd710f6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_04', '��߳�', 16, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71106cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_04', '���ֳ�', 17, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71116cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_04', '��ͷ��', 18, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71126cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_04', '���ų�', 19, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71136cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_04', '���䳵', 20, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71146cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_04', '����ݳ�', 21, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71156cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_04', '�Զ�������', 22, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71166cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_05', '���޻�', 23, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71176cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_05', '��߻�', 24, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71186cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_05', '���泵', 25, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd71196cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_05', '���ۻ�', 26, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd711a6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_05', 'ֱ�ۻ�', 27, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd711b6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_05', '���ۻ�', 28, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

insert into scmdata.t_machine_equipment (MACHINE_EQUIPMENT_ID, COMPANY_ID, EQUIPMENT_CATEGORY_ID, EQUIPMENT_NAME, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME, TEMPLATE_TYPE)
values ('ec7381fd711c6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'EQUIPMENT_05', '���Ի�����', 29, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:43', 'dd-mm-yyyy hh24:mi:ss'), 'TYPE_00');

---Ʒ����ϵģ�����ʼ��
insert into scmdata.t_quality_control (QUALITY_CONTROL_ID, COMPANY_ID, DEPARTMENT_ID, QUALITY_CONTROL_LINK_ID, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd711d6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'CONTROL_00', 'CONTROL_00_00', 1, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:50', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_quality_control (QUALITY_CONTROL_ID, COMPANY_ID, DEPARTMENT_ID, QUALITY_CONTROL_LINK_ID, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd711e6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'CONTROL_01', 'CONTROL_01_00', 2, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:50', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_quality_control (QUALITY_CONTROL_ID, COMPANY_ID, DEPARTMENT_ID, QUALITY_CONTROL_LINK_ID, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd711f6cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'CONTROL_02', 'CONTROL_02_00', 3, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:50', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_quality_control (QUALITY_CONTROL_ID, COMPANY_ID, DEPARTMENT_ID, QUALITY_CONTROL_LINK_ID, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd71206cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'CONTROL_02', 'CONTROL_02_01', 4, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:50', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_quality_control (QUALITY_CONTROL_ID, COMPANY_ID, DEPARTMENT_ID, QUALITY_CONTROL_LINK_ID, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd71216cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'CONTROL_02', 'CONTROL_02_02', 5, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:50', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_quality_control (QUALITY_CONTROL_ID, COMPANY_ID, DEPARTMENT_ID, QUALITY_CONTROL_LINK_ID, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd71226cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'CONTROL_03', 'CONTROL_03_00', 6, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:50', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_quality_control (QUALITY_CONTROL_ID, COMPANY_ID, DEPARTMENT_ID, QUALITY_CONTROL_LINK_ID, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd71236cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'CONTROL_04', 'CONTROL_04_00', 7, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:50', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_quality_control (QUALITY_CONTROL_ID, COMPANY_ID, DEPARTMENT_ID, QUALITY_CONTROL_LINK_ID, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd71246cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'CONTROL_04', 'CONTROL_04_01', 8, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:50', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_quality_control (QUALITY_CONTROL_ID, COMPANY_ID, DEPARTMENT_ID, QUALITY_CONTROL_LINK_ID, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd71256cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'CONTROL_04', 'CONTROL_04_02', 9, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:50', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_quality_control (QUALITY_CONTROL_ID, COMPANY_ID, DEPARTMENT_ID, QUALITY_CONTROL_LINK_ID, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd71266cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'CONTROL_05', 'CONTROL_05_00', 10, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:50', 'dd-mm-yyyy hh24:mi:ss'));

insert into scmdata.t_quality_control (QUALITY_CONTROL_ID, COMPANY_ID, DEPARTMENT_ID, QUALITY_CONTROL_LINK_ID, SEQNO, PAUSE, REMARKS, UPDATE_ID, UPDATE_TIME, CREATE_ID, CREATE_TIME)
values ('ec7381fd71276cd6e0533c281cacebbb', 'b6cc680ad0f599cde0531164a8c0337f', 'CONTROL_05', 'CONTROL_05_01', 11, 0, null, null, null, 'ADMIN', to_date('02-11-2022 09:10:50', 'dd-mm-yyyy hh24:mi:ss'));
