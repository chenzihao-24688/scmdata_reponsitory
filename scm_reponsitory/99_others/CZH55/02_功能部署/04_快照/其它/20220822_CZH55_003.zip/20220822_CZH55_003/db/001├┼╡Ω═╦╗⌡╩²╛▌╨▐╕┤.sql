BEGIN
  UPDATE scmdata.cmx_return_management_int T SET T.SUP_ID='73577',t.port_status ='SP' WHERE T.EXG_ID='YWTX20821000015' AND T.GOO_ID='806339' AND T.PORT_STATUS = 'SE';
END;
/
